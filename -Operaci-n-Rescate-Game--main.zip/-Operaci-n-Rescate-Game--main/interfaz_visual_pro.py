"""
interfaz_visual_pro.py — Operación Rescate: Cumbres Salvajes
Interfaz visual mejorada para el proyecto.

Mejoras:
- Fondo con montañas, bosque, campamento y helicóptero dibujado en Pygame.
- Tarjetas con avatar de rescatistas.
- Dos equipos de expedición.
- Drag & Drop.
- Harmony Meter grande.
- Panel de objetivo, roles, kits, tiempo y resultado con estrellas.
- Conexión con Algoritmo_1.py.

Ejecutar:
    pip install pygame
    python interfaz_visual_pro.py

Coloca este archivo en la misma carpeta que Algoritmo_1.py
"""

import pygame
import sys
import math
import random
from typing import Optional

try:
    from Algoritmo_1 import resolver_distribucion
    ALGORITMO_DISPONIBLE = True
except ImportError:
    ALGORITMO_DISPONIBLE = False
    print("⚠️ Algoritmo_1.py no encontrado. Modo visual solamente.")

ANCHO, ALTO = 1366, 768
FPS = 60
CANTIDAD_EQUIPOS = 2
PERSONAS_POR_EQUIPO = 3

BG_TOP = (20, 32, 52)
BG_BOTTOM = (10, 18, 30)
PANEL = (25, 35, 50)
BORDE = (96, 120, 150)
TEXTO = (240, 245, 250)
SUBTEXTO = (165, 180, 200)
DORADO = (255, 194, 76)
NARANJA = (255, 133, 55)
VERDE = (88, 220, 120)
AZUL = (80, 170, 250)
MORADO = (190, 105, 235)
ROJO = (230, 80, 75)
AMARILLO = (245, 210, 70)

ROLES_COLORES = {
    "Rastreadora": VERDE, "Rastreador": VERDE,
    "Paramédico": AZUL, "Paramédica": AZUL,
    "Escaladora": NARANJA, "Escalador": NARANJA,
    "Cargador": MORADO, "Cargadora": MORADO,
}
ROLES_ICONOS = {
    "Rastreadora": "R", "Rastreador": "R",
    "Paramédico": "+", "Paramédica": "+",
    "Escaladora": "A", "Escalador": "A",
    "Cargador": "C", "Cargadora": "C",
}

RESCATISTAS = [
    {"nombre": "Ana", "habilidad": 72, "rol": "Rastreadora"},
    {"nombre": "Luis", "habilidad": 68, "rol": "Paramédico"},
    {"nombre": "Marta", "habilidad": 75, "rol": "Escaladora"},
    {"nombre": "Carlos", "habilidad": 40, "rol": "Cargador"},
    {"nombre": "Sofía", "habilidad": 55, "rol": "Rastreadora"},
    {"nombre": "Tomás", "habilidad": 80, "rol": "Escalador"},
]

pygame.init()
FUENTES = {}


def fuente(size, bold=False):
    key = (size, bold)
    if key not in FUENTES:
        FUENTES[key] = pygame.font.SysFont("segoeui", size, bold=bold)
    return FUENTES[key]


def texto(surf, msg, x, y, size=18, color=TEXTO, bold=False, align="center"):
    img = fuente(size, bold).render(str(msg), True, color)
    rect = img.get_rect()
    if align == "center": rect.center = (x, y)
    elif align == "left": rect.midleft = (x, y)
    elif align == "right": rect.midright = (x, y)
    surf.blit(img, rect)


def rect_round(surf, rect, color, radius=16, border=0, border_color=BORDE):
    pygame.draw.rect(surf, color, rect, border_radius=radius)
    if border:
        pygame.draw.rect(surf, border_color, rect, width=border, border_radius=radius)


def sombra(surf, rect, alpha=90, offset=8):
    layer = pygame.Surface((rect.w + 22, rect.h + 22), pygame.SRCALPHA)
    pygame.draw.rect(layer, (0, 0, 0, alpha), layer.get_rect(), border_radius=22)
    surf.blit(layer, (rect.x - 6, rect.y + offset))


def lerp(c1, c2, t):
    return tuple(int(c1[i] + (c2[i] - c1[i]) * t) for i in range(3))


def color_habilidad(n):
    if n >= 70: return VERDE
    if n >= 45: return AMARILLO
    return ROJO


def estrella(cx, cy, r):
    pts = []
    for i in range(10):
        ang = math.radians(-90 + i * 36)
        rr = r if i % 2 == 0 else r * 0.45
        pts.append((cx + math.cos(ang) * rr, cy + math.sin(ang) * rr))
    return pts


class Fondo:
    def __init__(self):
        self.particulas = []
        for _ in range(90):
            self.particulas.append([
                random.randint(0, ANCHO), random.randint(0, ALTO),
                random.uniform(-0.25, 0.25), random.uniform(-0.15, 0.15),
                random.choice([DORADO, VERDE, AZUL]), random.randint(1, 3)
            ])

    def dibujar(self, surf):
        for y in range(ALTO):
            t = y / ALTO
            pygame.draw.line(surf, lerp(BG_TOP, BG_BOTTOM, t), (0, y), (ANCHO, y))

        pygame.draw.circle(surf, (255, 180, 95), (190, 160), 55)
        pygame.draw.polygon(surf, (38, 55, 76), [(0, 590), (210, 230), (420, 590)])
        pygame.draw.polygon(surf, (44, 65, 90), [(250, 600), (560, 160), (870, 600)])
        pygame.draw.polygon(surf, (30, 45, 65), [(760, 610), (1050, 200), (1366, 610)])
        pygame.draw.polygon(surf, (225, 230, 236), [(560, 160), (512, 235), (610, 235)])
        pygame.draw.polygon(surf, (225, 230, 236), [(1050, 200), (1008, 265), (1095, 265)])

        for x in range(0, ANCHO, 70):
            base = 610
            pygame.draw.polygon(surf, (18, 65, 45), [(x, base), (x + 35, base - 120), (x + 70, base)])
            pygame.draw.rect(surf, (55, 38, 25), (x + 32, base - 25, 8, 42))

        # Campamento y helicóptero
        pygame.draw.polygon(surf, (150, 70, 35), [(1125, 615), (1230, 455), (1335, 615)])
        pygame.draw.polygon(surf, (210, 105, 45), [(1165, 615), (1230, 455), (1295, 615)])
        pygame.draw.rect(surf, (255, 190, 80), (1210, 560, 45, 40), border_radius=4)
        pygame.draw.ellipse(surf, (170, 40, 38), (1010, 165, 130, 42))
        pygame.draw.rect(surf, (170, 40, 38), (1125, 175, 65, 10))
        pygame.draw.line(surf, (40, 40, 40), (990, 160), (1165, 160), 4)
        pygame.draw.circle(surf, (190, 220, 235), (1055, 185), 14)

        for p in self.particulas:
            p[0] += p[2]; p[1] += p[3]
            if p[0] < 0: p[0] = ANCHO
            if p[0] > ANCHO: p[0] = 0
            if p[1] < 0: p[1] = ALTO
            if p[1] > ALTO: p[1] = 0
            pygame.draw.circle(surf, p[4], (int(p[0]), int(p[1])), p[5])


class Boton:
    def __init__(self, rect, label, color, hover):
        self.rect = pygame.Rect(rect)
        self.label = label
        self.color = color
        self.hover_color = hover
        self.hover = False

    def evento(self, e):
        if e.type == pygame.MOUSEMOTION:
            self.hover = self.rect.collidepoint(e.pos)
        if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1 and self.rect.collidepoint(e.pos):
            return True
        return False

    def dibujar(self, surf):
        c = self.hover_color if self.hover else self.color
        sombra(surf, self.rect, 70, 6)
        rect_round(surf, self.rect, c, 14, 2, BORDE)
        texto(surf, self.label, self.rect.centerx, self.rect.centery, 17, TEXTO, True)


class Tarjeta:
    W, H = 160, 195
    def __init__(self, data, x, y):
        self.data = data
        self.origen = (x, y)
        self.rect = pygame.Rect(x, y, self.W, self.H)
        self.drag = False
        self.offset = (0, 0)
        self.zona = None

    @property
    def nombre(self): return self.data["nombre"]
    @property
    def habilidad(self): return self.data["habilidad"]
    @property
    def rol(self): return self.data["rol"]

    def iniciar(self, pos):
        if self.zona:
            self.zona.remover(self)
            self.zona = None
        self.drag = True
        self.offset = (self.rect.x - pos[0], self.rect.y - pos[1])

    def mover(self, pos):
        if self.drag:
            self.rect.x = pos[0] + self.offset[0]
            self.rect.y = pos[1] + self.offset[1]

    def soltar(self, zonas):
        self.drag = False
        for z in zonas:
            if self.rect.colliderect(z.rect) and z.puede_recibir():
                z.recibir(self)
                self.zona = z
                self.rect.center = z.slot_center(len(z.tarjetas) - 1)
                return True
        self.rect.topleft = self.origen
        return False

    def dibujar_avatar(self, surf, rect, color_rol):
        cx, cy = rect.centerx, rect.y + 58
        pygame.draw.circle(surf, color_rol, (cx, cy), 42)
        pygame.draw.circle(surf, (12, 18, 27), (cx, cy), 42, 4)
        pygame.draw.circle(surf, (224, 168, 125), (cx, cy - 2), 20)
        pygame.draw.arc(surf, color_rol, (cx - 23, cy - 27, 46, 35), math.pi, 2 * math.pi, 12)
        pygame.draw.rect(surf, color_rol, (cx - 23, cy - 13, 46, 8), border_radius=4)
        pygame.draw.circle(surf, (20, 25, 30), (cx - 7, cy - 2), 2)
        pygame.draw.circle(surf, (20, 25, 30), (cx + 7, cy - 2), 2)
        pygame.draw.polygon(surf, color_rol, [(cx - 30, cy + 42), (cx + 30, cy + 42), (cx + 20, cy + 22), (cx - 20, cy + 22)])

    def dibujar(self, surf):
        color_rol = ROLES_COLORES.get(self.rol, AZUL)
        if self.drag: sombra(surf, self.rect, 130, 12)
        base = (58, 76, 100) if self.drag else (32, 44, 61)
        rect_round(surf, self.rect, base, 18, 2, color_rol)
        pygame.draw.rect(surf, color_rol, (self.rect.x, self.rect.y, self.rect.w, 8), border_radius=6)
        self.dibujar_avatar(surf, self.rect, color_rol)
        texto(surf, self.rol.upper(), self.rect.x + 14, self.rect.y + 112, 11, color_rol, True, "left")
        texto(surf, self.nombre, self.rect.x + 14, self.rect.y + 137, 24, TEXTO, True, "left")
        pygame.draw.circle(surf, color_rol, (self.rect.right - 30, self.rect.y + 135), 24)
        texto(surf, self.habilidad, self.rect.right - 30, self.rect.y + 135, 17, TEXTO, True)
        stars = max(1, min(5, round(self.habilidad / 20)))
        for i in range(5):
            c = DORADO if i < stars else (65, 75, 90)
            pygame.draw.polygon(surf, c, estrella(self.rect.x + 20 + i * 22, self.rect.y + 165, 9))
        bar = pygame.Rect(self.rect.x + 14, self.rect.bottom - 18, self.rect.w - 28, 9)
        rect_round(surf, bar, (12, 18, 28), 5)
        fill = pygame.Rect(bar.x, bar.y, int(bar.w * self.habilidad / 100), bar.h)
        rect_round(surf, fill, color_habilidad(self.habilidad), 5)


class ZonaEquipo:
    def __init__(self, rect, nombre, color):
        self.rect = pygame.Rect(rect)
        self.nombre = nombre
        self.color = color
        self.tarjetas = []
        self.activa = False

    def puede_recibir(self): return len(self.tarjetas) < PERSONAS_POR_EQUIPO
    def recibir(self, tarjeta): self.tarjetas.append(tarjeta)
    def remover(self, tarjeta):
        if tarjeta in self.tarjetas:
            self.tarjetas.remove(tarjeta)
            self.reordenar()
    def reordenar(self):
        for i, t in enumerate(self.tarjetas): t.rect.center = self.slot_center(i)
    def slot_center(self, i): return self.rect.centerx, self.rect.y + 92 + i * 106
    def desviacion(self):
        if len(self.tarjetas) <= 1: return 0
        h = [t.habilidad for t in self.tarjetas]
        return max(h) - min(h)
    def dibujar(self, surf):
        base = (25, 45, 38) if self.activa else (22, 32, 47)
        sombra(surf, self.rect, 80, 8)
        rect_round(surf, self.rect, base, 20, 2, self.color)
        texto(surf, self.nombre, self.rect.centerx, self.rect.y + 28, 20, self.color, True)
        texto(surf, f"{len(self.tarjetas)} / {PERSONAS_POR_EQUIPO}", self.rect.centerx, self.rect.y + 55, 15, TEXTO, True)
        for i in range(PERSONAS_POR_EQUIPO):
            if i < len(self.tarjetas): continue
            slot = pygame.Rect(0, 0, self.rect.w - 48, 82)
            slot.center = self.slot_center(i)
            rect_round(surf, slot, (18, 25, 35), 13, 2, (70, 85, 105))
            pygame.draw.circle(surf, (52, 62, 75), (slot.centerx, slot.centery - 8), 16)
            pygame.draw.rect(surf, (52, 62, 75), (slot.centerx - 24, slot.centery + 10, 48, 22), border_radius=8)


class HarmonyMeter:
    def __init__(self, rect):
        self.rect = pygame.Rect(rect)
        self.valor = 0
        self.desv = 0
        self.optimo = 0
    def actualizar(self, zonas, optimo):
        self.desv = sum(z.desviacion() for z in zonas)
        self.optimo = optimo
        target = min(self.desv / 100, 1)
        self.valor += (target - self.valor) * 0.07
    def dibujar(self, surf):
        sombra(surf, self.rect, 90, 8)
        rect_round(surf, self.rect, (22, 32, 47), 18, 2, BORDE)
        texto(surf, "HARMONY METER", self.rect.x + 25, self.rect.y + 32, 22, DORADO, True, "left")
        center = (self.rect.x + 210, self.rect.y + 165)
        radius = 105
        for i in range(0, 101, 2):
            ang = math.radians(200 - i * 2.2)
            x1 = center[0] + math.cos(ang) * (radius - 12)
            y1 = center[1] - math.sin(ang) * (radius - 12)
            x2 = center[0] + math.cos(ang) * radius
            y2 = center[1] - math.sin(ang) * radius
            c = VERDE if i < 35 else AMARILLO if i < 65 else ROJO
            pygame.draw.line(surf, c, (x1, y1), (x2, y2), 4)
        angle = math.radians(200 - self.valor * 220)
        px = center[0] + math.cos(angle) * (radius - 25)
        py = center[1] - math.sin(angle) * (radius - 25)
        cneedle = VERDE if self.valor < .35 else AMARILLO if self.valor < .65 else ROJO
        pygame.draw.line(surf, cneedle, center, (px, py), 7)
        pygame.draw.circle(surf, TEXTO, center, 12)
        porcentaje = max(0, 100 - self.desv)
        texto(surf, f"{porcentaje}%", self.rect.right - 90, self.rect.y + 130, 42, cneedle, True)
        estado = "ARMONIOSO" if self.valor < .35 else "MODERADO" if self.valor < .65 else "RIESGOSO"
        texto(surf, estado, self.rect.right - 90, self.rect.y + 175, 18, cneedle, True)
        texto(surf, f"Desviación: {self.desv}", self.rect.right - 90, self.rect.y + 210, 14, SUBTEXTO)
        texto(surf, f"Óptimo IA: {self.optimo}" if self.optimo else "Analiza con IA", self.rect.right - 90, self.rect.y + 235, 14, VERDE if self.optimo else SUBTEXTO, True)


def calcular_estrellas(usuario, optimo):
    if optimo == 0: return 3 if usuario == 0 else 1
    ratio = usuario / optimo
    if ratio <= 1: return 3
    if ratio <= 1.5: return 2
    return 1


class Juego:
    def __init__(self):
        pygame.display.set_caption("Operación Rescate: Cumbres Salvajes")
        self.screen = pygame.display.set_mode((ANCHO, ALTO))
        self.clock = pygame.time.Clock()
        self.fondo = Fondo()
        self.btn_analizar = Boton((640, 620, 250, 58), "ANALIZAR IA", (55, 155, 72), (80, 205, 105))
        self.btn_enviar = Boton((910, 620, 250, 58), "ENVIAR EQUIPO", (38, 120, 180), (60, 160, 230))
        self.btn_limpiar = Boton((1180, 620, 150, 58), "LIMPIAR", (85, 92, 105), (115, 125, 145))
        self.iniciar()

    def iniciar(self):
        self.tarjetas = []
        for i, data in enumerate(RESCATISTAS):
            col = i % 3; row = i // 3
            self.tarjetas.append(Tarjeta(data.copy(), 300 + col * 180, 145 + row * 220))
        self.zonas = [ZonaEquipo((815, 210, 190, 390), "EQUIPO 1", VERDE), ZonaEquipo((1035, 210, 190, 390), "EQUIPO 2", AZUL)]
        self.meter = HarmonyMeter((295, 585, 320, 155))
        self.arrastrada: Optional[Tarjeta] = None
        self.desv_optima = 0
        self.resultado_ia = None
        self.mostrar_resultado = False
        self.kits = 3
        self.tiempo_total = 120
        self.ticks_inicio = pygame.time.get_ticks()

    def ejecutar_ia(self):
        if not ALGORITMO_DISPONIBLE:
            print("⚠️ No se encontró Algoritmo_1.py.")
            return
        personas = [{"nombre": t.nombre, "habilidad": t.habilidad} for t in self.tarjetas]
        try:
            resultado = resolver_distribucion(personas, cantidad_equipos=CANTIDAD_EQUIPOS, guardar_historial=False)
            self.resultado_ia = resultado
            self.desv_optima = resultado["mejor_desviacion"]
            print("\n✅ RESULTADO IA")
            print("Mejor desviación:", self.desv_optima)
            for i, eq in enumerate(resultado["mejores_equipos"], 1): print(f"Equipo {i}: {eq}")
            print("Estadísticas:", resultado["estadisticas"])
        except Exception as e:
            print("❌ Error IA:", e)

    def limpiar(self):
        for t in self.tarjetas:
            t.zona = None; t.drag = False; t.rect.topleft = t.origen
        for z in self.zonas: z.tarjetas.clear()
        self.mostrar_resultado = False

    def equipos_completos(self): return all(len(z.tarjetas) == PERSONAS_POR_EQUIPO for z in self.zonas)
    def desviacion_usuario(self): return sum(z.desviacion() for z in self.zonas)

    def eventos(self):
        for e in pygame.event.get():
            if e.type == pygame.QUIT: pygame.quit(); sys.exit()
            if e.type == pygame.KEYDOWN:
                if e.key == pygame.K_ESCAPE: pygame.quit(); sys.exit()
                if e.key == pygame.K_r: self.iniciar()
            if self.btn_analizar.evento(e): self.ejecutar_ia()
            if self.btn_limpiar.evento(e): self.limpiar()
            if self.btn_enviar.evento(e):
                if self.equipos_completos():
                    if self.resultado_ia is None: self.ejecutar_ia()
                    self.mostrar_resultado = True
                else: print("⚠️ Debes completar los 2 equipos antes de enviar.")
            if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1 and not self.mostrar_resultado:
                pos = e.pos
                for z in self.zonas:
                    for t in reversed(z.tarjetas):
                        if t.rect.collidepoint(pos): t.iniciar(pos); self.arrastrada = t; return
                for t in reversed(self.tarjetas):
                    if t.rect.collidepoint(pos) and t.zona is None: t.iniciar(pos); self.arrastrada = t; return
            if e.type == pygame.MOUSEMOTION:
                if self.arrastrada:
                    self.arrastrada.mover(e.pos)
                    for z in self.zonas: z.activa = z.rect.collidepoint(e.pos)
            if e.type == pygame.MOUSEBUTTONUP and e.button == 1:
                if self.arrastrada:
                    self.arrastrada.soltar(self.zonas)
                    self.arrastrada = None
                    for z in self.zonas: z.activa = False

    def panel_superior(self):
        logo = pygame.Rect(25, 25, 230, 110)
        rect_round(self.screen, logo, (15, 25, 38), 18, 2, DORADO)
        texto(self.screen, "OPERACIÓN", logo.centerx, logo.y + 42, 32, DORADO, True)
        texto(self.screen, "RESCATE", logo.centerx, logo.y + 76, 38, NARANJA, True)
        texto(self.screen, "Cumbres Salvajes", logo.centerx, logo.y + 100, 13, TEXTO, True)
        mis = pygame.Rect(500, 30, 360, 75)
        rect_round(self.screen, mis, (18, 30, 44), 18, 2, VERDE)
        texto(self.screen, "MISIÓN ACTIVA", mis.centerx, mis.y + 23, 18, DORADO, True)
        texto(self.screen, "BOSQUE ESCARPADO", mis.centerx, mis.y + 52, 24, TEXTO, True)
        elapsed = (pygame.time.get_ticks() - self.ticks_inicio) // 1000
        remaining = max(0, self.tiempo_total - elapsed)
        time_rect = pygame.Rect(920, 30, 180, 75)
        rect_round(self.screen, time_rect, (18, 30, 44), 18, 2, DORADO)
        color = VERDE if remaining > 55 else AMARILLO if remaining > 20 else ROJO
        texto(self.screen, "TIEMPO", time_rect.centerx, time_rect.y + 23, 15, DORADO, True)
        texto(self.screen, f"{remaining}s", time_rect.centerx, time_rect.y + 53, 28, color, True)
        kit_rect = pygame.Rect(1125, 30, 190, 75)
        rect_round(self.screen, kit_rect, (18, 30, 44), 18, 2, ROJO)
        texto(self.screen, "KITS", kit_rect.centerx, kit_rect.y + 23, 15, DORADO, True)
        texto(self.screen, f"{self.kits} / 3", kit_rect.centerx, kit_rect.y + 53, 28, TEXTO, True)

    def panel_objetivo(self):
        panel = pygame.Rect(25, 560, 240, 165)
        sombra(self.screen, panel, 95, 8)
        rect_round(self.screen, panel, (25, 35, 48), 16, 2, DORADO)
        texto(self.screen, "OBJETIVO", panel.x + 18, panel.y + 28, 18, DORADO, True, "left")
        lines = ["Forma dos equipos", "de rescate equilibrados", "para encontrar al perrito", "antes del anochecer."]
        for i, line in enumerate(lines): texto(self.screen, line, panel.x + 18, panel.y + 64 + i * 23, 15, TEXTO, False, "left")

    def panel_rescatistas(self):
        panel = pygame.Rect(280, 120, 520, 440)
        sombra(self.screen, panel, 85, 8)
        rect_round(self.screen, panel, (24, 34, 49), 20, 2, BORDE)
        texto(self.screen, "RESCATISTAS DISPONIBLES", panel.x + 28, panel.y + 32, 22, DORADO, True, "left")

    def panel_expedicion(self):
        panel = pygame.Rect(800, 120, 440, 500)
        sombra(self.screen, panel, 85, 8)
        rect_round(self.screen, panel, (24, 34, 49), 20, 2, BORDE)
        texto(self.screen, "ZONA DE EXPEDICIÓN", panel.centerx, panel.y + 38, 26, DORADO, True)
        texto(self.screen, "Arrastra aquí a los rescatistas", panel.centerx, panel.y + 70, 16, TEXTO)

    def panel_roles(self):
        panel = pygame.Rect(1030, 585, 305, 150)
        rect_round(self.screen, panel, (25, 35, 48), 16, 2, DORADO)
        texto(self.screen, "ROLES", panel.x + 20, panel.y + 24, 17, DORADO, True, "left")
        roles = [("Rastreador", VERDE, "Encuentra rutas"), ("Paramédico", AZUL, "Brinda soporte"), ("Escalador", NARANJA, "Supera obstáculos"), ("Cargador", MORADO, "Transporta equipo")]
        for i, (r, c, d) in enumerate(roles):
            y = panel.y + 52 + i * 23
            pygame.draw.circle(self.screen, c, (panel.x + 25, y), 7)
            texto(self.screen, f"{r}: {d}", panel.x + 42, y, 13, TEXTO, False, "left")

    def resultado(self):
        overlay = pygame.Surface((ANCHO, ALTO), pygame.SRCALPHA); overlay.fill((0, 0, 0, 175)); self.screen.blit(overlay, (0, 0))
        panel = pygame.Rect(ANCHO // 2 - 285, ALTO // 2 - 205, 570, 410)
        sombra(self.screen, panel, 130, 10); rect_round(self.screen, panel, (25, 35, 50), 24, 3, DORADO)
        user = self.desviacion_usuario(); stars = calcular_estrellas(user, self.desv_optima)
        texto(self.screen, "MISIÓN COMPLETADA", panel.centerx, panel.y + 50, 34, DORADO, True)
        for i in range(3):
            c = DORADO if i < stars else (70, 80, 95)
            pygame.draw.polygon(self.screen, c, estrella(panel.centerx - 80 + i * 80, panel.y + 125, 34))
        texto(self.screen, f"Tu desviación total: {user}", panel.centerx, panel.y + 210, 21, TEXTO, True)
        texto(self.screen, f"Óptimo IA: {self.desv_optima}", panel.centerx, panel.y + 245, 20, VERDE, True)
        msg, col = ("Excelente. Equipo perfectamente equilibrado.", VERDE) if stars == 3 else (("Buen trabajo. Puedes mejorar un poco.", AMARILLO) if stars == 2 else ("Equipo riesgoso. Revisa la combinación.", ROJO))
        texto(self.screen, msg, panel.centerx, panel.y + 292, 18, col, True)
        texto(self.screen, "Presiona R para reiniciar", panel.centerx, panel.y + 360, 16, DORADO, True)

    def dibujar_tarjeta_compacta(self, t):
        r = pygame.Rect(0, 0, t.zona.rect.w - 48, 82); r.center = t.rect.center
        color = ROLES_COLORES.get(t.rol, AZUL)
        rect_round(self.screen, r, (30, 42, 60), 12, 2, color)
        pygame.draw.circle(self.screen, color, (r.x + 38, r.centery), 24)
        texto(self.screen, ROLES_ICONOS.get(t.rol, "?"), r.x + 38, r.centery, 22, TEXTO, True)
        texto(self.screen, t.nombre, r.x + 72, r.y + 28, 17, TEXTO, True, "left")
        texto(self.screen, t.rol, r.x + 72, r.y + 52, 12, color, True, "left")
        texto(self.screen, t.habilidad, r.right - 28, r.centery, 18, color, True)

    def dibujar(self):
        self.fondo.dibujar(self.screen)
        self.panel_superior(); self.panel_objetivo(); self.panel_rescatistas(); self.panel_expedicion(); self.panel_roles()
        self.meter.actualizar(self.zonas, self.desv_optima); self.meter.dibujar(self.screen)
        self.btn_analizar.dibujar(self.screen); self.btn_enviar.dibujar(self.screen); self.btn_limpiar.dibujar(self.screen)
        for z in self.zonas: z.dibujar(self.screen)
        for t in self.tarjetas:
            if t.zona is None and not t.drag: t.dibujar(self.screen)
        for z in self.zonas:
            for t in z.tarjetas:
                if not t.drag: self.dibujar_tarjeta_compacta(t)
        if self.arrastrada: self.arrastrada.dibujar(self.screen)
        if self.mostrar_resultado: self.resultado()
        pygame.display.flip()

    def run(self):
        while True:
            self.eventos(); self.dibujar(); self.clock.tick(FPS)

if __name__ == "__main__":
    Juego().run()
