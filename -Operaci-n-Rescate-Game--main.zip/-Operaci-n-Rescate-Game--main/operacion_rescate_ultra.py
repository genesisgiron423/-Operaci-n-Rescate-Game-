"""
operacion_rescate_ultra.py
Operación Rescate: Cumbres Salvajes — Interfaz tipo videojuego

✅ Menú principal cinematográfico
✅ Selección de misiones
✅ Fondo por escenario: bosque, nieve, montaña, avalancha
✅ Rescatistas dibujados como personajes
✅ Cartas estilo videojuego
✅ Drag & Drop con brillo
✅ Dos equipos de expedición
✅ Mapa central de rescate
✅ Harmony Meter profesional
✅ Animación de análisis IA
✅ Animación de helicóptero
✅ Resultado final tipo juego
✅ Conexión con Algoritmo_1.py

Ejecutar:
    pip install pygame
    python operacion_rescate_ultra.py

Debe estar en la misma carpeta que Algoritmo_1.py
"""

import pygame
import sys
import math
import random
from typing import Optional


# ============================================================
# CONEXIÓN CON ALGORITMO
# ============================================================
try:
    from Algoritmo_1 import resolver_distribucion
    ALGORITMO_DISPONIBLE = True
except Exception:
    ALGORITMO_DISPONIBLE = False


# ============================================================
# CONFIGURACIÓN
# ============================================================
ANCHO, ALTO = 1366, 768
FPS = 60

CANTIDAD_EQUIPOS = 2
PERSONAS_POR_EQUIPO = 3

pygame.init()
pygame.font.init()


# ============================================================
# COLORES
# ============================================================
BLANCO = (245, 248, 252)
NEGRO = (8, 12, 18)
TINTA = (16, 23, 35)
PANEL = (20, 30, 44)
PANEL2 = (31, 45, 63)
BORDE = (94, 120, 152)
GRIS = (160, 174, 195)

DORADO = (255, 194, 72)
NARANJA = (255, 130, 55)
VERDE = (88, 220, 120)
AZUL = (80, 170, 250)
MORADO = (190, 105, 235)
ROJO = (230, 78, 75)
AMARILLO = (245, 210, 70)

ROLES = {
    "Rastreadora": {"color": VERDE, "icono": "R", "desc": "Encuentra rutas"},
    "Rastreador": {"color": VERDE, "icono": "R", "desc": "Encuentra rutas"},
    "Paramédico": {"color": AZUL, "icono": "+", "desc": "Primeros auxilios"},
    "Paramédica": {"color": AZUL, "icono": "+", "desc": "Primeros auxilios"},
    "Escaladora": {"color": NARANJA, "icono": "A", "desc": "Supera obstáculos"},
    "Escalador": {"color": NARANJA, "icono": "A", "desc": "Supera obstáculos"},
    "Cargador": {"color": MORADO, "icono": "C", "desc": "Transporta equipo"},
    "Cargadora": {"color": MORADO, "icono": "C", "desc": "Transporta equipo"},
}


# ============================================================
# DATOS
# ============================================================
RESCATISTAS = [
    {"nombre": "Ana", "habilidad": 72, "rol": "Rastreadora", "genero": "f"},
    {"nombre": "Luis", "habilidad": 68, "rol": "Paramédico", "genero": "m"},
    {"nombre": "Marta", "habilidad": 75, "rol": "Escaladora", "genero": "f"},
    {"nombre": "Carlos", "habilidad": 40, "rol": "Cargador", "genero": "m"},
    {"nombre": "Sofía", "habilidad": 55, "rol": "Rastreadora", "genero": "f"},
    {"nombre": "Tomás", "habilidad": 80, "rol": "Escalador", "genero": "m"},
]

MISIONES = [
    {
        "nombre": "Sendero del Bosque",
        "tipo": "bosque",
        "sub": "Rescate del cachorro perdido",
        "objetivo": "Encuentra al cachorro antes del anochecer.",
        "victima": "🐶",
        "tiempo": 120,
        "color": VERDE,
    },
    {
        "nombre": "Campamento Bajo Tormenta",
        "tipo": "nieve",
        "sub": "Evacuación de campistas",
        "objetivo": "Evacúa a los campistas antes de la tormenta.",
        "victima": "🏕",
        "tiempo": 100,
        "color": AZUL,
    },
    {
        "nombre": "Risco Alto",
        "tipo": "montana",
        "sub": "Gato atrapado en la cornisa",
        "objetivo": "Rescata al gato sin romper el equilibrio del equipo.",
        "victima": "🐱",
        "tiempo": 90,
        "color": NARANJA,
    },
    {
        "nombre": "La Gran Avalancha",
        "tipo": "avalancha",
        "sub": "Boss final de montaña",
        "objetivo": "Forma el equipo perfecto para salvar montañistas.",
        "victima": "🚩",
        "tiempo": 75,
        "color": ROJO,
    },
]


# ============================================================
# UTILIDADES
# ============================================================
FUENTES = {}

def font(size, bold=False):
    key = (size, bold)
    if key not in FUENTES:
        FUENTES[key] = pygame.font.SysFont("segoeui", size, bold=bold)
    return FUENTES[key]

def txt(s, text, x, y, size=18, color=BLANCO, bold=False, align="center"):
    img = font(size, bold).render(str(text), True, color)
    r = img.get_rect()
    if align == "center":
        r.center = (x, y)
    elif align == "left":
        r.midleft = (x, y)
    elif align == "right":
        r.midright = (x, y)
    s.blit(img, r)

def rr(s, rect, color, rad=18, border=0, bcolor=BORDE):
    pygame.draw.rect(s, color, rect, border_radius=rad)
    if border:
        pygame.draw.rect(s, bcolor, rect, width=border, border_radius=rad)

def shadow(s, rect, alpha=90, dy=8):
    layer = pygame.Surface((rect.w + 22, rect.h + 22), pygame.SRCALPHA)
    pygame.draw.rect(layer, (0, 0, 0, alpha), layer.get_rect(), border_radius=24)
    s.blit(layer, (rect.x - 6, rect.y + dy))

def lerp(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))

def skill_color(v):
    if v >= 70:
        return VERDE
    if v >= 45:
        return AMARILLO
    return ROJO

def star_points(cx, cy, r):
    pts = []
    for i in range(10):
        ang = math.radians(-90 + i * 36)
        rr_ = r if i % 2 == 0 else r * 0.45
        pts.append((cx + math.cos(ang) * rr_, cy + math.sin(ang) * rr_))
    return pts


# ============================================================
# FONDO CINEMATOGRÁFICO
# ============================================================
class World:
    def __init__(self):
        self.particles = []
        for _ in range(130):
            self.particles.append({
                "x": random.randint(0, ANCHO),
                "y": random.randint(0, ALTO),
                "vx": random.uniform(-0.3, 0.3),
                "vy": random.uniform(-0.2, 0.2),
                "r": random.randint(1, 3),
                "c": random.choice([DORADO, VERDE, AZUL, AMARILLO]),
            })
        self.cloud = 0
        self.heli_x = -160

    def draw_gradient(self, surf, top, bottom):
        for y in range(ALTO):
            t = y / ALTO
            pygame.draw.line(surf, lerp(top, bottom, t), (0, y), (ANCHO, y))

    def draw_tree(self, surf, x, y, scale=1):
        trunk = pygame.Rect(x - 5 * scale, y - 45 * scale, 10 * scale, 45 * scale)
        pygame.draw.rect(surf, (77, 48, 30), trunk)
        pygame.draw.polygon(surf, (18, 78, 48), [(x - 38*scale, y - 30*scale), (x, y - 115*scale), (x + 38*scale, y - 30*scale)])
        pygame.draw.polygon(surf, (22, 95, 58), [(x - 32*scale, y - 70*scale), (x, y - 145*scale), (x + 32*scale, y - 70*scale)])

    def draw_tent(self, surf, x, y):
        pygame.draw.polygon(surf, (110, 58, 34), [(x, y), (x + 95, y - 150), (x + 190, y)])
        pygame.draw.polygon(surf, (215, 105, 45), [(x + 35, y), (x + 95, y - 150), (x + 155, y)])
        pygame.draw.line(surf, DORADO, (x + 95, y - 150), (x + 95, y), 3)
        pygame.draw.rect(surf, (255, 190, 70), (x + 77, y - 55, 40, 42), border_radius=5)

    def draw_helicopter(self, surf, x, y):
        pygame.draw.ellipse(surf, (180, 35, 35), (x, y, 120, 38))
        pygame.draw.rect(surf, (180, 35, 35), (x + 105, y + 12, 70, 10))
        pygame.draw.polygon(surf, (180, 35, 35), [(x + 170, y + 17), (x + 195, y), (x + 190, y + 35)])
        pygame.draw.line(surf, (30, 30, 35), (x - 20, y - 5), (x + 150, y - 5), 4)
        pygame.draw.circle(surf, (185, 220, 235), (x + 45, y + 18), 13)
        pygame.draw.line(surf, (20, 20, 22), (x + 25, y + 40), (x + 100, y + 40), 3)

    def draw_background(self, surf, mission_type):
        if mission_type == "bosque":
            top, bottom = (30, 48, 78), (9, 24, 30)
            accent = VERDE
        elif mission_type == "nieve":
            top, bottom = (45, 66, 92), (18, 28, 40)
            accent = AZUL
        elif mission_type == "montana":
            top, bottom = (54, 42, 66), (18, 21, 32)
            accent = NARANJA
        else:
            top, bottom = (50, 50, 62), (16, 20, 28)
            accent = ROJO

        self.draw_gradient(surf, top, bottom)

        # sol/luna
        sun_color = (255, 184, 90) if mission_type != "nieve" else (220, 235, 255)
        pygame.draw.circle(surf, sun_color, (185, 175), 58)
        glow = pygame.Surface((260, 260), pygame.SRCALPHA)
        pygame.draw.circle(glow, (*sun_color, 45), (130, 130), 125)
        surf.blit(glow, (55, 45))

        # nubes
        self.cloud += 0.25
        for i in range(4):
            cx = int((i * 360 + self.cloud) % (ANCHO + 220)) - 120
            cy = 70 + i * 25
            pygame.draw.ellipse(surf, (255, 255, 255, 35), (cx, cy, 150, 32))

        # montañas con profundidad
        pygame.draw.polygon(surf, (35, 52, 75), [(0, 650), (250, 250), (520, 650)])
        pygame.draw.polygon(surf, (45, 63, 86), [(280, 660), (600, 150), (930, 660)])
        pygame.draw.polygon(surf, (28, 42, 63), [(740, 660), (1050, 210), (1366, 660)])
        pygame.draw.polygon(surf, (235, 239, 244), [(600, 150), (545, 240), (658, 240)])
        pygame.draw.polygon(surf, (235, 239, 244), [(1050, 210), (1003, 285), (1105, 285)])

        # árboles/campamento
        for x in range(-20, ANCHO + 80, 72):
            self.draw_tree(surf, x, 690, random.choice([0.9, 1, 1.15]))

        self.draw_tent(surf, 1120, 685)

        # sendero
        pygame.draw.polygon(surf, (75, 60, 45), [(560, ALTO), (760, ALTO), (690, 500), (625, 500)])
        pygame.draw.line(surf, (190, 145, 70), (660, 735), (660, 500), 3)

        # objetivo en el mapa
        target = pygame.Rect(615, 385, 135, 95)
        rr(surf, target, (20, 30, 42), 18, 2, accent)
        txt(surf, "OBJETIVO", target.centerx, target.y + 22, 15, DORADO, True)
        victima = "🐶" if mission_type == "bosque" else "🏕" if mission_type == "nieve" else "🐱" if mission_type == "montana" else "🚩"
        txt(surf, victima, target.centerx, target.y + 62, 35, BLANCO, True)

        # helicóptero
        self.heli_x = (self.heli_x + 0.7) % (ANCHO + 260) - 160
        self.draw_helicopter(surf, self.heli_x, 135)

        # partículas / nieve / hojas
        for p in self.particles:
            p["x"] += p["vx"]
            p["y"] += p["vy"] + (0.35 if mission_type in ["nieve", "avalancha"] else 0)
            if p["x"] < 0: p["x"] = ANCHO
            if p["x"] > ANCHO: p["x"] = 0
            if p["y"] < 0: p["y"] = ALTO
            if p["y"] > ALTO: p["y"] = 0
            c = (230, 240, 255) if mission_type in ["nieve", "avalancha"] else p["c"]
            pygame.draw.circle(surf, c, (int(p["x"]), int(p["y"])), p["r"])


# ============================================================
# BOTONES Y CARTAS
# ============================================================
class Button:
    def __init__(self, rect, label, color, hover):
        self.rect = pygame.Rect(rect)
        self.label = label
        self.color = color
        self.hover = hover
        self.over = False

    def event(self, e):
        if e.type == pygame.MOUSEMOTION:
            self.over = self.rect.collidepoint(e.pos)
        if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1 and self.rect.collidepoint(e.pos):
            return True
        return False

    def draw(self, s):
        c = self.hover if self.over else self.color
        shadow(s, self.rect, 80, 8)
        rr(s, self.rect, c, 16, 2, BORDE)
        txt(s, self.label, self.rect.centerx, self.rect.centery, 18, BLANCO, True)


class CharacterCard:
    W, H = 145, 205

    def __init__(self, data, x, y):
        self.data = data
        self.origin = (x, y)
        self.rect = pygame.Rect(x, y, self.W, self.H)
        self.drag = False
        self.offset = (0, 0)
        self.zone = None
        self.scale_anim = 0

    @property
    def nombre(self): return self.data["nombre"]
    @property
    def habilidad(self): return self.data["habilidad"]
    @property
    def rol(self): return self.data["rol"]

    def start_drag(self, pos):
        if self.zone:
            self.zone.remove(self)
            self.zone = None
        self.drag = True
        self.offset = (self.rect.x - pos[0], self.rect.y - pos[1])

    def move(self, pos):
        if self.drag:
            self.rect.x = pos[0] + self.offset[0]
            self.rect.y = pos[1] + self.offset[1]

    def drop(self, zones):
        self.drag = False
        for z in zones:
            if self.rect.colliderect(z.rect) and z.can_take():
                z.add(self)
                self.zone = z
                self.rect.center = z.slot_center(len(z.cards) - 1)
                return True
        self.rect.topleft = self.origin
        return False

    def draw_person(self, s, x, y, role_color, big=False):
        # cuerpo estilo personaje, no círculo plano
        skin = (225, 168, 122)
        dark = (18, 22, 28)

        # mochila
        pygame.draw.ellipse(s, (42, 55, 43), (x - 42, y + 5, 38, 58))
        pygame.draw.ellipse(s, (42, 55, 43), (x + 5, y + 5, 38, 58))

        # cuerpo
        pygame.draw.polygon(s, role_color, [(x - 34, y + 78), (x + 34, y + 78), (x + 24, y + 22), (x - 24, y + 22)])
        pygame.draw.line(s, dark, (x, y + 25), (x, y + 78), 3)
        pygame.draw.line(s, dark, (x - 24, y + 50), (x + 24, y + 50), 2)

        # cabeza
        pygame.draw.circle(s, skin, (x, y), 24)

        # casco
        pygame.draw.arc(s, role_color, (x - 28, y - 31, 56, 42), math.pi, 2 * math.pi, 14)
        pygame.draw.rect(s, role_color, (x - 29, y - 13, 58, 9), border_radius=5)

        # cabello/ojos
        pygame.draw.arc(s, dark, (x - 20, y - 17, 40, 22), math.pi, 2 * math.pi, 3)
        pygame.draw.circle(s, dark, (x - 8, y - 1), 2)
        pygame.draw.circle(s, dark, (x + 8, y - 1), 2)
        pygame.draw.arc(s, (120, 55, 40), (x - 9, y + 4, 18, 10), 0, math.pi, 2)

        # distintivo
        icon = ROLES[self.rol]["icono"]
        pygame.draw.circle(s, (12, 18, 28), (x + 25, y + 35), 13)
        txt(s, icon, x + 25, y + 35, 14, role_color, True)

    def draw(self, s):
        role_color = ROLES[self.rol]["color"]
        hovering = self.rect.collidepoint(pygame.mouse.get_pos())
        base = (31, 43, 61) if not hovering else (44, 62, 86)

        if self.drag:
            shadow(s, self.rect, 150, 12)
            base = (55, 75, 100)

        rr(s, self.rect, base, 20, 2, role_color)
        pygame.draw.rect(s, role_color, (self.rect.x, self.rect.y, self.rect.w, 8), border_radius=8)

        # glow
        glow = pygame.Surface((self.rect.w, self.rect.h), pygame.SRCALPHA)
        pygame.draw.rect(glow, (*role_color, 28), glow.get_rect(), border_radius=20)
        s.blit(glow, self.rect.topleft)

        self.draw_person(s, self.rect.centerx, self.rect.y + 62, role_color)

        txt(s, self.rol.upper(), self.rect.x + 14, self.rect.y + 121, 11, role_color, True, "left")
        txt(s, self.nombre, self.rect.x + 14, self.rect.y + 146, 23, BLANCO, True, "left")

        pygame.draw.circle(s, role_color, (self.rect.right - 30, self.rect.y + 145), 24)
        txt(s, self.habilidad, self.rect.right - 30, self.rect.y + 145, 17, BLANCO, True)

        # estrellas
        stars = max(1, min(5, round(self.habilidad / 20)))
        for i in range(5):
            c = DORADO if i < stars else (68, 76, 90)
            pygame.draw.polygon(s, c, star_points(self.rect.x + 20 + i * 21, self.rect.y + 177, 8))

        bar = pygame.Rect(self.rect.x + 14, self.rect.bottom - 17, self.rect.w - 28, 8)
        rr(s, bar, (10, 15, 24), 5)
        fill = pygame.Rect(bar.x, bar.y, int(bar.w * self.habilidad / 100), bar.h)
        rr(s, fill, skill_color(self.habilidad), 5)


class TeamZone:
    def __init__(self, rect, title, color):
        self.rect = pygame.Rect(rect)
        self.title = title
        self.color = color
        self.cards = []
        self.active = False

    def can_take(self):
        return len(self.cards) < PERSONAS_POR_EQUIPO

    def add(self, card):
        self.cards.append(card)

    def remove(self, card):
        if card in self.cards:
            self.cards.remove(card)
            self.reflow()

    def reflow(self):
        for i, c in enumerate(self.cards):
            c.rect.center = self.slot_center(i)

    def slot_center(self, i):
        return self.rect.centerx, self.rect.y + 96 + i * 98

    def deviation(self):
        if len(self.cards) <= 1:
            return 0
        vals = [c.habilidad for c in self.cards]
        return max(vals) - min(vals)

    def draw(self, s):
        base = (17, 35, 30) if self.active else (17, 26, 40)
        shadow(s, self.rect, 80, 8)
        rr(s, self.rect, base, 18, 2, self.color)
        txt(s, self.title, self.rect.centerx, self.rect.y + 27, 20, self.color, True)
        txt(s, f"{len(self.cards)} / {PERSONAS_POR_EQUIPO}", self.rect.centerx, self.rect.y + 55, 14, BLANCO, True)

        for i in range(PERSONAS_POR_EQUIPO):
            slot = pygame.Rect(0, 0, self.rect.w - 38, 76)
            slot.center = self.slot_center(i)
            if i < len(self.cards):
                continue
            rr(s, slot, (15, 23, 34), 13, 2, (65, 82, 105))
            pygame.draw.circle(s, (54, 65, 80), (slot.centerx, slot.centery - 9), 16)
            pygame.draw.rect(s, (54, 65, 80), (slot.centerx - 25, slot.centery + 10, 50, 22), border_radius=8)


class Harmony:
    def __init__(self, rect):
        self.rect = pygame.Rect(rect)
        self.visual = 0
        self.dev = 0
        self.opt = 0

    def update(self, zones, opt):
        self.dev = sum(z.deviation() for z in zones)
        self.opt = opt
        target = min(self.dev / 100, 1)
        self.visual += (target - self.visual) * 0.08

    def draw(self, s):
        shadow(s, self.rect, 90, 8)
        rr(s, self.rect, (19, 28, 42), 18, 2, BORDE)
        txt(s, "HARMONY METER", self.rect.x + 28, self.rect.y + 34, 22, DORADO, True, "left")
        txt(s, "Equilibrio total de los equipos", self.rect.x + 28, self.rect.y + 62, 14, GRIS, False, "left")

        center = (self.rect.x + 185, self.rect.y + 165)
        radius = 104

        # arco de medidor
        for i in range(0, 101, 2):
            ang = math.radians(200 - i * 2.2)
            x1 = center[0] + math.cos(ang) * (radius - 14)
            y1 = center[1] - math.sin(ang) * (radius - 14)
            x2 = center[0] + math.cos(ang) * radius
            y2 = center[1] - math.sin(ang) * radius
            c = VERDE if i < 35 else AMARILLO if i < 65 else ROJO
            pygame.draw.line(s, c, (x1, y1), (x2, y2), 4)

        angle = math.radians(200 - self.visual * 220)
        px = center[0] + math.cos(angle) * (radius - 28)
        py = center[1] - math.sin(angle) * (radius - 28)
        c = VERDE if self.visual < .35 else AMARILLO if self.visual < .65 else ROJO

        pygame.draw.line(s, c, center, (px, py), 7)
        pygame.draw.circle(s, BLANCO, center, 12)
        pygame.draw.circle(s, c, center, 7)

        percent = max(0, 100 - self.dev)
        txt(s, f"{percent}%", self.rect.right - 105, self.rect.y + 120, 42, c, True)
        estado = "ARMONIOSO" if self.visual < .35 else "MODERADO" if self.visual < .65 else "RIESGOSO"
        txt(s, estado, self.rect.right - 105, self.rect.y + 165, 18, c, True)
        txt(s, f"Desviación: {self.dev}", self.rect.right - 105, self.rect.y + 205, 14, GRIS)
        if self.opt > 0:
            txt(s, f"Óptimo IA: {self.opt}", self.rect.right - 105, self.rect.y + 230, 14, VERDE, True)
        else:
            txt(s, "Sin analizar", self.rect.right - 105, self.rect.y + 230, 14, GRIS)


# ============================================================
# GAME
# ============================================================
class Game:
    def __init__(self):
        pygame.display.set_caption("Operación Rescate: Cumbres Salvajes — Ultra")
        self.screen = pygame.display.set_mode((ANCHO, ALTO))
        self.clock = pygame.time.Clock()
        self.world = World()
        self.state = "menu"
        self.mission_idx = 0
        self.mission = MISIONES[0]

        self.btn_play = Button((ANCHO//2 - 140, 438, 280, 62), "JUGAR", (166, 88, 42), (220, 118, 55))
        self.btn_exit = Button((ANCHO//2 - 140, 518, 280, 54), "SALIR", (78, 86, 104), (105, 115, 140))

        self.mission_buttons = []
        for i, m in enumerate(MISIONES):
            self.mission_buttons.append(Button((255, 145 + i*112, 850, 82), f"{i+1}. {m['nombre']}", m["color"], lerp(m["color"], BLANCO, 0.18)))

        self.btn_back = Button((35, 30, 130, 44), "VOLVER", (70, 86, 108), (98, 118, 145))
        self.btn_ai = Button((780, 650, 220, 55), "ANALIZAR IA", (48, 145, 75), (80, 205, 110))
        self.btn_send = Button((1020, 650, 220, 55), "ENVIAR", (38, 115, 180), (62, 160, 235))
        self.btn_clear = Button((1247, 650, 95, 55), "LIMPIAR", (78, 86, 104), (110, 122, 145))

        self.new_game()

    def new_game(self):
        self.cards = []
        for i, data in enumerate(RESCATISTAS):
            col = i % 3
            row = i // 3
            self.cards.append(CharacterCard(data.copy(), 280 + col * 165, 150 + row * 235))

        self.zones = [
            TeamZone((870, 205, 185, 380), "EQUIPO 1", VERDE),
            TeamZone((1085, 205, 185, 380), "EQUIPO 2", AZUL),
        ]

        self.harmony = Harmony((275, 575, 470, 160))
        self.dragged: Optional[CharacterCard] = None
        self.result_ai = None
        self.opt_dev = 0
        self.result = False
        self.analysis = False
        self.analysis_start = 0
        self.launch_anim = False
        self.launch_start = 0
        self.start_ticks = pygame.time.get_ticks()
        self.kits = 3

    def run_ai(self):
        if not ALGORITMO_DISPONIBLE:
            print("⚠️ Algoritmo_1.py no encontrado.")
            return
        personas = [{"nombre": c.nombre, "habilidad": c.habilidad} for c in self.cards]
        try:
            res = resolver_distribucion(personas, cantidad_equipos=CANTIDAD_EQUIPOS, guardar_historial=False)
            self.result_ai = res
            self.opt_dev = res["mejor_desviacion"]
            print("\n✅ IA completada")
            print("Mejor desviación:", self.opt_dev)
            for i, eq in enumerate(res["mejores_equipos"], 1):
                print(f"Equipo {i}: {eq}")
            print("Estadísticas:", res["estadisticas"])
        except Exception as e:
            print("❌ Error IA:", e)

    def complete(self):
        return all(len(z.cards) == PERSONAS_POR_EQUIPO for z in self.zones)

    def user_dev(self):
        return sum(z.deviation() for z in self.zones)

    def stars(self):
        u = self.user_dev()
        o = self.opt_dev
        if o == 0:
            return 3 if u == 0 else 1
        if u / o <= 1:
            return 3
        if u / o <= 1.5:
            return 2
        return 1

    def events(self):
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if e.type == pygame.KEYDOWN:
                if e.key == pygame.K_ESCAPE:
                    pygame.quit()
                    sys.exit()
                if e.key == pygame.K_r and self.state == "game":
                    self.new_game()

            if self.state == "menu":
                if self.btn_play.event(e):
                    self.state = "missions"
                if self.btn_exit.event(e):
                    pygame.quit()
                    sys.exit()

            elif self.state == "missions":
                if self.btn_back.event(e):
                    self.state = "menu"
                for i, b in enumerate(self.mission_buttons):
                    if b.event(e):
                        self.mission_idx = i
                        self.mission = MISIONES[i]
                        self.new_game()
                        self.state = "game"

            elif self.state == "game":
                if self.btn_back.event(e):
                    self.state = "missions"
                if self.btn_ai.event(e) and not self.analysis:
                    self.analysis = True
                    self.analysis_start = pygame.time.get_ticks()

                if self.btn_clear.event(e):
                    self.new_game()

                if self.btn_send.event(e):
                    if self.complete():
                        if self.result_ai is None:
                            self.run_ai()
                        self.launch_anim = True
                        self.launch_start = pygame.time.get_ticks()
                    else:
                        print("⚠️ Completa los dos equipos antes de enviar.")

                if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1 and not self.result and not self.analysis:
                    pos = e.pos
                    for z in self.zones:
                        for c in reversed(z.cards):
                            if c.rect.collidepoint(pos):
                                c.start_drag(pos)
                                self.dragged = c
                                return
                    for c in reversed(self.cards):
                        if c.rect.collidepoint(pos) and c.zone is None:
                            c.start_drag(pos)
                            self.dragged = c
                            return

                if e.type == pygame.MOUSEMOTION:
                    if self.dragged:
                        self.dragged.move(e.pos)
                        for z in self.zones:
                            z.active = z.rect.collidepoint(e.pos)

                if e.type == pygame.MOUSEBUTTONUP and e.button == 1:
                    if self.dragged:
                        self.dragged.drop(self.zones)
                        self.dragged = None
                        for z in self.zones:
                            z.active = False

    def draw_menu(self):
        self.world.draw_background(self.screen, "bosque")
        overlay = pygame.Surface((ANCHO, ALTO), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 80))
        self.screen.blit(overlay, (0, 0))

        # Logo grande
        box = pygame.Rect(ANCHO//2 - 270, 130, 540, 260)
        shadow(self.screen, box, 130, 12)
        rr(self.screen, box, (15, 25, 38), 26, 3, DORADO)
        txt(self.screen, "OPERACIÓN", box.centerx, box.y + 82, 62, DORADO, True)
        txt(self.screen, "RESCATE", box.centerx, box.y + 155, 76, NARANJA, True)
        txt(self.screen, "CUMBRES SALVAJES", box.centerx, box.y + 218, 25, BLANCO, True)

        txt(self.screen, "Juego de estrategia con Backtracking y Podas", ANCHO//2, 408, 19, BLANCO)
        self.btn_play.draw(self.screen)
        self.btn_exit.draw(self.screen)

        estado = "Algoritmo_1.py conectado ✓" if ALGORITMO_DISPONIBLE else "Algoritmo_1.py no encontrado"
        txt(self.screen, estado, ANCHO//2, 650, 16, VERDE if ALGORITMO_DISPONIBLE else ROJO, True)

    def draw_missions(self):
        self.world.draw_background(self.screen, "montana")
        overlay = pygame.Surface((ANCHO, ALTO), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 95))
        self.screen.blit(overlay, (0, 0))

        self.btn_back.draw(self.screen)
        txt(self.screen, "SELECCIONA LA MISIÓN", ANCHO//2, 82, 42, DORADO, True)
        txt(self.screen, "Cada escenario cambia la atmósfera, el objetivo y el tiempo disponible.", ANCHO//2, 120, 18, BLANCO)

        for b, m in zip(self.mission_buttons, MISIONES):
            b.draw(self.screen)
            txt(self.screen, m["sub"], b.rect.x + 28, b.rect.y + 55, 15, BLANCO, False, "left")
            txt(self.screen, f"{m['tiempo']}s", b.rect.right - 35, b.rect.y + 31, 20, BLANCO, True, "right")
            txt(self.screen, m["victima"], b.rect.right - 115, b.rect.y + 41, 32, BLANCO, True)

    def top_hud(self):
        # Logo
        logo = pygame.Rect(25, 24, 210, 92)
        rr(self.screen, logo, (15, 24, 36), 18, 2, DORADO)
        txt(self.screen, "OPERACIÓN", logo.centerx, logo.y + 32, 28, DORADO, True)
        txt(self.screen, "RESCATE", logo.centerx, logo.y + 64, 35, NARANJA, True)

        # Misión
        mission_box = pygame.Rect(420, 25, 430, 80)
        rr(self.screen, mission_box, (15, 24, 36), 18, 2, self.mission["color"])
        txt(self.screen, "MISIÓN ACTIVA", mission_box.centerx, mission_box.y + 25, 18, DORADO, True)
        txt(self.screen, self.mission["nombre"].upper(), mission_box.centerx, mission_box.y + 55, 23, BLANCO, True)

        elapsed = (pygame.time.get_ticks() - self.start_ticks) // 1000
        remaining = max(0, self.mission["tiempo"] - elapsed)
        time_box = pygame.Rect(900, 25, 160, 80)
        rr(self.screen, time_box, (15, 24, 36), 18, 2, DORADO)
        txt(self.screen, "TIEMPO", time_box.centerx, time_box.y + 25, 16, DORADO, True)
        txt(self.screen, f"{remaining}s", time_box.centerx, time_box.y + 58, 30, VERDE if remaining > 45 else AMARILLO if remaining > 20 else ROJO, True)

        kit_box = pygame.Rect(1090, 25, 160, 80)
        rr(self.screen, kit_box, (15, 24, 36), 18, 2, ROJO)
        txt(self.screen, "KITS", kit_box.centerx, kit_box.y + 25, 16, DORADO, True)
        txt(self.screen, f"{self.kits} / 3", kit_box.centerx, kit_box.y + 58, 30, BLANCO, True)

    def draw_objective_panel(self):
        p = pygame.Rect(25, 548, 220, 160)
        shadow(self.screen, p, 100, 8)
        rr(self.screen, p, (18, 28, 42), 18, 2, DORADO)
        txt(self.screen, "OBJETIVO", p.x + 18, p.y + 30, 18, DORADO, True, "left")
        words = self.mission["objetivo"].split()
        lines = []
        line = ""
        for w in words:
            if len(line + " " + w) < 25:
                line += (" " if line else "") + w
            else:
                lines.append(line)
                line = w
        if line:
            lines.append(line)
        for i, l in enumerate(lines[:4]):
            txt(self.screen, l, p.x + 18, p.y + 68 + i*23, 15, BLANCO, False, "left")

    def draw_game(self):
        self.world.draw_background(self.screen, self.mission["tipo"])
        shade = pygame.Surface((ANCHO, ALTO), pygame.SRCALPHA)
        shade.fill((0, 0, 0, 50))
        self.screen.blit(shade, (0, 0))

        self.top_hud()
        self.draw_objective_panel()

        # Panel rescatistas
        panel_cards = pygame.Rect(260, 128, 535, 435)
        shadow(self.screen, panel_cards, 80, 8)
        rr(self.screen, panel_cards, (20, 30, 44), 22, 2, BORDE)
        txt(self.screen, "RESCATISTAS DISPONIBLES", panel_cards.x + 28, panel_cards.y + 32, 22, DORADO, True, "left")

        # Zona expedición
        panel_zone = pygame.Rect(820, 128, 480, 500)
        shadow(self.screen, panel_zone, 80, 8)
        rr(self.screen, panel_zone, (20, 30, 44), 22, 2, BORDE)
        txt(self.screen, "ZONA DE EXPEDICIÓN", panel_zone.centerx, panel_zone.y + 35, 28, DORADO, True)
        txt(self.screen, "Arrastra los rescatistas para formar los equipos", panel_zone.centerx, panel_zone.y + 68, 15, BLANCO)

        for z in self.zones:
            z.draw(self.screen)

        # Harmony
        self.harmony.update(self.zones, self.opt_dev)
        self.harmony.draw(self.screen)

        # Botones
        self.btn_ai.draw(self.screen)
        self.btn_send.draw(self.screen)
        self.btn_clear.draw(self.screen)

        # Roles panel
        roles = pygame.Rect(1020, 565, 320, 75)
        rr(self.screen, roles, (18, 28, 42), 16, 2, DORADO)
        txt(self.screen, "ROLES", roles.x + 18, roles.y + 22, 15, DORADO, True, "left")
        role_list = [("R", VERDE, "Rutas"), ("+", AZUL, "Soporte"), ("A", NARANJA, "Escala"), ("C", MORADO, "Carga")]
        for i, (ic, c, d) in enumerate(role_list):
            x = roles.x + 20 + i * 75
            pygame.draw.circle(self.screen, c, (x, roles.y + 52), 11)
            txt(self.screen, ic, x, roles.y + 52, 12, BLANCO, True)
            txt(self.screen, d, x + 18, roles.y + 52, 12, BLANCO, False, "left")

        # Cards
        for c in self.cards:
            if c.zone is None and not c.drag:
                c.draw(self.screen)

        # Compact cards in zones
        for z in self.zones:
            for c in z.cards:
                if not c.drag:
                    self.draw_compact_card(c)

        if self.dragged:
            self.dragged.draw(self.screen)

        if self.analysis:
            self.draw_analysis()

        if self.launch_anim:
            self.draw_launch()

        if self.result:
            self.draw_result()

    def draw_compact_card(self, card):
        r = pygame.Rect(0, 0, card.zone.rect.w - 38, 76)
        r.center = card.rect.center
        color = ROLES[card.rol]["color"]
        rr(self.screen, r, (25, 36, 52), 13, 2, color)
        pygame.draw.circle(self.screen, color, (r.x + 36, r.centery), 23)
        txt(self.screen, ROLES[card.rol]["icono"], r.x + 36, r.centery, 18, BLANCO, True)
        txt(self.screen, card.nombre, r.x + 68, r.y + 28, 16, BLANCO, True, "left")
        txt(self.screen, card.rol, r.x + 68, r.y + 52, 11, color, True, "left")
        txt(self.screen, card.habilidad, r.right - 25, r.centery, 17, color, True)

    def draw_analysis(self):
        elapsed = pygame.time.get_ticks() - self.analysis_start
        if elapsed > 1600:
            self.analysis = False
            self.run_ai()
            return

        overlay = pygame.Surface((ANCHO, ALTO), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 155))
        self.screen.blit(overlay, (0, 0))

        box = pygame.Rect(ANCHO//2 - 250, ALTO//2 - 115, 500, 230)
        shadow(self.screen, box, 130, 12)
        rr(self.screen, box, (18, 28, 42), 24, 3, VERDE)

        txt(self.screen, "ANALIZANDO COMBINACIONES", box.centerx, box.y + 55, 25, DORADO, True)
        txt(self.screen, "Backtracking + podas en ejecución", box.centerx, box.y + 88, 17, BLANCO)

        progress = min(1, elapsed / 1600)
        bar = pygame.Rect(box.x + 70, box.y + 140, box.w - 140, 24)
        rr(self.screen, bar, (10, 15, 22), 12)
        fill = pygame.Rect(bar.x, bar.y, int(bar.w * progress), bar.h)
        rr(self.screen, fill, VERDE, 12)

        dots = "." * (1 + (elapsed // 300) % 3)
        txt(self.screen, f"Buscando óptimo{dots}", box.centerx, box.y + 185, 16, GRIS)

    def draw_launch(self):
        elapsed = pygame.time.get_ticks() - self.launch_start
        if elapsed > 1400:
            self.launch_anim = False
            self.result = True
            return

        # helicóptero grande cruzando
        t = elapsed / 1400
        x = int(-180 + t * (ANCHO + 360))
        y = 315 - int(math.sin(t * math.pi) * 80)
        self.world.draw_helicopter(self.screen, x, y)

        txt(self.screen, "🚁 EQUIPO EN RUTA...", ANCHO//2, 120, 32, DORADO, True)

    def draw_result(self):
        overlay = pygame.Surface((ANCHO, ALTO), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 185))
        self.screen.blit(overlay, (0, 0))

        p = pygame.Rect(ANCHO//2 - 320, ALTO//2 - 230, 640, 460)
        shadow(self.screen, p, 160, 12)
        rr(self.screen, p, (18, 28, 42), 26, 3, DORADO)

        stars = self.stars()
        txt(self.screen, "MISIÓN EXITOSA", p.centerx, p.y + 58, 40, DORADO, True)
        txt(self.screen, self.mission["sub"], p.centerx, p.y + 98, 19, BLANCO)

        for i in range(3):
            c = DORADO if i < stars else (70, 80, 95)
            pygame.draw.polygon(self.screen, c, star_points(p.centerx - 90 + i*90, p.y + 170, 38))

        txt(self.screen, f"Tu desviación total: {self.user_dev()}", p.centerx, p.y + 260, 22, BLANCO, True)
        txt(self.screen, f"Óptimo IA: {self.opt_dev}", p.centerx, p.y + 300, 22, VERDE, True)

        if stars == 3:
            msg, col = "Excelente. Equipo perfectamente equilibrado."
        elif stars == 2:
            msg, col = "Buen trabajo. Puedes mejorar un poco."
        else:
            msg, col = "Equipo riesgoso. Revisa la combinación."

        txt(self.screen, msg, p.centerx, p.y + 350, 18, col, True)
        txt(self.screen, "Presiona R para jugar otra vez", p.centerx, p.y + 410, 16, DORADO, True)

    def draw(self):
        if self.state == "menu":
            self.draw_menu()
        elif self.state == "missions":
            self.draw_missions()
        elif self.state == "game":
            self.draw_game()
        pygame.display.flip()

    def run(self):
        while True:
            self.events()
            self.draw()
            self.clock.tick(FPS)


if __name__ == "__main__":
    Game().run()
