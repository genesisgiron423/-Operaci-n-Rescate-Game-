"""
interfaz_1_mejorada.py — Operación Rescate: Cumbres Salvajes
CAPA 2: Interfaz Gráfica Premium con Drag & Drop
Autor interfaz base: Andrew/Mateo
Versión mejorada: Interfaz tipo videojuego + conexión con Algoritmo_1.py

Cómo ejecutar:
    pip install pygame
    python interfaz_1_mejorada.py

IMPORTANTE:
Este archivo debe estar en la misma carpeta que Algoritmo_1.py
"""

import pygame
import sys
import math
import random
from typing import Optional

# ─────────────────────────────────────────────
# IMPORTAR MOTOR LÓGICO
# ─────────────────────────────────────────────
try:
    from Algoritmo_1 import resolver_distribucion
    ALGORITMO_DISPONIBLE = True
except ImportError:
    ALGORITMO_DISPONIBLE = False
    print("⚠️ Algoritmo_1.py no encontrado. La interfaz funcionará en modo visual.")


# ─────────────────────────────────────────────
# CONFIGURACIÓN GENERAL
# ─────────────────────────────────────────────
ANCHO, ALTO = 1280, 720
FPS = 60

CANTIDAD_EQUIPOS = 2
PERSONAS_POR_EQUIPO = 3
TAMANO_EQUIPO = PERSONAS_POR_EQUIPO

# ─────────────────────────────────────────────
# PALETA DE COLORES
# ─────────────────────────────────────────────
COLOR_FONDO = (16, 23, 35)
COLOR_FONDO_2 = (25, 35, 52)
COLOR_PANEL = (34, 48, 68)
COLOR_PANEL_2 = (45, 63, 88)
COLOR_PANEL_BORDE = (90, 115, 150)

COLOR_TEXTO = (235, 240, 248)
COLOR_SUBTEXTO = (155, 170, 190)
COLOR_ACENTO = (255, 190, 65)
COLOR_NARANJA = (255, 130, 55)

COLOR_VERDE = (80, 215, 120)
COLOR_AMARILLO = (240, 205, 65)
COLOR_ROJO = (225, 75, 70)
COLOR_AZUL = (85, 165, 245)
COLOR_MORADO = (190, 105, 230)

COLOR_BOTON = (60, 135, 100)
COLOR_BOTON_HOV = (78, 175, 128)
COLOR_BOTON_NARANJA = (170, 95, 45)
COLOR_BOTON_NARANJA_HOV = (220, 120, 55)
COLOR_BOTON_GRIS = (70, 88, 115)
COLOR_BOTON_GRIS_HOV = (95, 115, 150)

ROLES_COLORES = {
    "Rastreador": COLOR_VERDE,
    "Rastreadora": COLOR_VERDE,
    "Paramédico": COLOR_AZUL,
    "Paramédica": COLOR_AZUL,
    "Escalador": COLOR_NARANJA,
    "Escaladora": COLOR_NARANJA,
    "Cargador": COLOR_MORADO,
    "Cargadora": COLOR_MORADO,
}

ROLES_ICONOS = {
    "Rastreador": "⌖",
    "Rastreadora": "⌖",
    "Paramédico": "+",
    "Paramédica": "+",
    "Escalador": "▲",
    "Escaladora": "▲",
    "Cargador": "▣",
    "Cargadora": "▣",
}


# ─────────────────────────────────────────────
# DATOS DEL NIVEL
# ─────────────────────────────────────────────
RESCATISTAS_NIVEL_1 = [
    {"nombre": "Ana",    "habilidad": 72, "rol": "Rastreadora"},
    {"nombre": "Luis",   "habilidad": 68, "rol": "Paramédico"},
    {"nombre": "Marta",  "habilidad": 75, "rol": "Escaladora"},
    {"nombre": "Carlos", "habilidad": 40, "rol": "Cargador"},
    {"nombre": "Sofía",  "habilidad": 55, "rol": "Rastreadora"},
    {"nombre": "Tomás",  "habilidad": 80, "rol": "Escalador"},
]

MISIONES = [
    {
        "titulo": "Sendero del Bosque",
        "subtitulo": "Rescatar a un perrito perdido",
        "escenario": "BOSQUE",
        "objetivo": "Forma un equipo equilibrado para encontrar al perrito antes del anochecer.",
        "color": (70, 155, 95),
        "tiempo": 120,
    },
    {
        "titulo": "Tormenta Blanca",
        "subtitulo": "Evacuar campistas",
        "escenario": "NIEVE",
        "objetivo": "Elige un equipo capaz de avanzar en nieve y clima extremo.",
        "color": (90, 165, 220),
        "tiempo": 100,
    },
    {
        "titulo": "Risco Alto",
        "subtitulo": "Rescatar a un gato atrapado",
        "escenario": "MONTAÑA",
        "objetivo": "Organiza un equipo seguro para una misión de altura.",
        "color": (205, 130, 70),
        "tiempo": 90,
    },
    {
        "titulo": "Gran Avalancha",
        "subtitulo": "Boss Final",
        "escenario": "AVALANCHA",
        "objetivo": "La misión final exige la mayor armonía posible.",
        "color": (210, 85, 85),
        "tiempo": 75,
    },
]


# ─────────────────────────────────────────────
# FUNCIONES AUXILIARES
# ─────────────────────────────────────────────
_fuente_cache: dict = {}

def _fuente(tamanio: int, negrita: bool = False) -> pygame.font.Font:
    clave = (tamanio, negrita)
    if clave not in _fuente_cache:
        _fuente_cache[clave] = pygame.font.SysFont("segoeui", tamanio, bold=negrita)
    return _fuente_cache[clave]


def _dibujar_texto(surface, texto, x, y, tamanio, color, negrita=False, alineacion="center"):
    render = _fuente(tamanio, negrita).render(str(texto), True, color)
    rect = render.get_rect()

    if alineacion == "center":
        rect.center = (x, y)
    elif alineacion == "left":
        rect.midleft = (x, y)
    elif alineacion == "right":
        rect.midright = (x, y)

    surface.blit(render, rect)


def _rect(surface, color, rect, radio=14, borde=0, color_borde=COLOR_PANEL_BORDE):
    pygame.draw.rect(surface, color, rect, border_radius=radio)
    if borde > 0:
        pygame.draw.rect(surface, color_borde, rect, width=borde, border_radius=radio)


def _sombra(surface, rect, alpha=80, dy=8):
    sombra = pygame.Surface((rect.w + 16, rect.h + 16), pygame.SRCALPHA)
    pygame.draw.rect(sombra, (0, 0, 0, alpha), sombra.get_rect(), border_radius=18)
    surface.blit(sombra, (rect.x - 4, rect.y + dy))


def _interpolar(c1, c2, t):
    return tuple(int(c1[i] + (c2[i] - c1[i]) * t) for i in range(3))


def _color_por_nivel(nivel: int) -> tuple:
    if nivel >= 70:
        return COLOR_VERDE
    elif nivel >= 45:
        return COLOR_AMARILLO
    return COLOR_ROJO


def _color_harmony(valor: float) -> tuple:
    if valor < 0.5:
        t = valor * 2
        return _interpolar(COLOR_VERDE, COLOR_AMARILLO, t)
    t = (valor - 0.5) * 2
    return _interpolar(COLOR_AMARILLO, COLOR_ROJO, t)


def _ease_out(t: float) -> float:
    return 1 - (1 - t) ** 3


def _puntos_estrella(cx, cy, radio):
    puntos = []
    for i in range(10):
        ang = math.radians(-90 + i * 36)
        r = radio if i % 2 == 0 else radio * 0.45
        puntos.append((cx + r * math.cos(ang), cy + r * math.sin(ang)))
    return puntos


# ─────────────────────────────────────────────
# PARTÍCULAS DECORATIVAS
# ─────────────────────────────────────────────
class Particula:
    def __init__(self):
        self.x = random.randint(0, ANCHO)
        self.y = random.randint(0, ALTO)
        self.vx = random.uniform(-0.25, 0.25)
        self.vy = random.uniform(-0.18, 0.18)
        self.r = random.randint(1, 3)
        self.color = random.choice([COLOR_ACENTO, COLOR_VERDE, COLOR_AZUL, COLOR_NARANJA])
        self.alpha = random.randint(55, 130)

    def actualizar(self):
        self.x += self.vx
        self.y += self.vy
        if self.x < -10:
            self.x = ANCHO + 10
        if self.x > ANCHO + 10:
            self.x = -10
        if self.y < -10:
            self.y = ALTO + 10
        if self.y > ALTO + 10:
            self.y = -10

    def dibujar(self, surface):
        capa = pygame.Surface((8, 8), pygame.SRCALPHA)
        pygame.draw.circle(capa, (*self.color, self.alpha), (4, 4), self.r)
        surface.blit(capa, (self.x, self.y))


# ─────────────────────────────────────────────
# CLASE: BOTÓN
# ─────────────────────────────────────────────
class Boton:
    def __init__(self, x, y, ancho, alto, texto, color=COLOR_BOTON, color_hover=COLOR_BOTON_HOV):
        self.rect = pygame.Rect(x, y, ancho, alto)
        self.texto = texto
        self.color = color
        self.color_hover = color_hover
        self.hover = False
        self.activo = True

    def manejar_evento(self, evento: pygame.event.Event) -> bool:
        if evento.type == pygame.MOUSEMOTION:
            self.hover = self.rect.collidepoint(evento.pos)

        if evento.type == pygame.MOUSEBUTTONDOWN and evento.button == 1:
            if self.rect.collidepoint(evento.pos) and self.activo:
                return True
        return False

    def dibujar(self, surface):
        color = self.color_hover if self.hover and self.activo else self.color
        if not self.activo:
            color = (55, 62, 75)

        _sombra(surface, self.rect, 45, 6)
        _rect(surface, color, self.rect, 12, 2, COLOR_PANEL_BORDE)
        _dibujar_texto(surface, self.texto, self.rect.centerx, self.rect.centery, 15, COLOR_TEXTO, True)


# ─────────────────────────────────────────────
# CLASE: TARJETA DE RESCATISTA
# ─────────────────────────────────────────────
class TarjetaRescatista:
    ANCHO = 135
    ALTO = 160
    RADIO = 16

    def __init__(self, rescatista: dict, x: int, y: int):
        self.rescatista = rescatista
        self.origen_x = x
        self.origen_y = y
        self.rect = pygame.Rect(x, y, self.ANCHO, self.ALTO)

        self.arrastrando = False
        self.en_zona = None
        self.offset_x = 0
        self.offset_y = 0
        self.hover = False
        self.animando = False
        self.anim_progreso = 1.0
        self.pulso = random.random() * 10

    @property
    def nombre(self) -> str:
        return self.rescatista["nombre"]

    @property
    def habilidad(self) -> int:
        return self.rescatista["habilidad"]

    @property
    def rol(self) -> str:
        return self.rescatista.get("rol", "?")

    def iniciar_arrastre(self, mouse_x: int, mouse_y: int) -> None:
        if self.en_zona:
            self.en_zona.quitar_tarjeta(self)
            self.en_zona = None

        self.arrastrando = True
        self.offset_x = self.rect.x - mouse_x
        self.offset_y = self.rect.y - mouse_y

    def mover(self, mouse_x: int, mouse_y: int) -> None:
        if self.arrastrando:
            self.rect.x = mouse_x + self.offset_x
            self.rect.y = mouse_y + self.offset_y

    def soltar(self, zonas: list) -> bool:
        self.arrastrando = False

        for zona in zonas:
            if zona.rect.colliderect(self.rect) and zona.puede_recibir():
                zona.recibir_tarjeta(self)
                self.en_zona = zona
                self.rect.center = zona.siguiente_posicion()
                return True

        self._iniciar_retorno()
        return False

    def _iniciar_retorno(self) -> None:
        self.animando = True
        self.anim_progreso = 0.0
        self.anim_inicio_x = self.rect.x
        self.anim_inicio_y = self.rect.y

    def actualizar(self) -> None:
        self.pulso += 0.05

        if self.animando:
            self.anim_progreso = min(self.anim_progreso + 0.08, 1.0)
            t = _ease_out(self.anim_progreso)
            self.rect.x = int(self.anim_inicio_x + (self.origen_x - self.anim_inicio_x) * t)
            self.rect.y = int(self.anim_inicio_y + (self.origen_y - self.anim_inicio_y) * t)

            if self.anim_progreso >= 1.0:
                self.animando = False

    def dibujar(self, surface: pygame.Surface) -> None:
        color_rol = ROLES_COLORES.get(self.rol, (120, 140, 160))
        icono = ROLES_ICONOS.get(self.rol, "?")

        if self.arrastrando:
            color_fondo = (75, 100, 132)
            _sombra(surface, self.rect, 115, 10)
        elif self.hover:
            color_fondo = (61, 82, 110)
        else:
            color_fondo = COLOR_PANEL_2

        _rect(surface, color_fondo, self.rect, self.RADIO, 2, COLOR_PANEL_BORDE)

        # Barra superior del rol
        barra = pygame.Rect(self.rect.x, self.rect.y, self.ANCHO, 10)
        pygame.draw.rect(surface, color_rol, barra, border_radius=8)

        # Círculo de habilidad
        cx = self.rect.centerx
        cy = self.rect.y + 50
        pygame.draw.circle(surface, color_rol, (cx, cy), 31)
        pygame.draw.circle(surface, COLOR_FONDO, (cx, cy), 31, 4)

        _dibujar_texto(surface, icono, cx, cy - 8, 20, COLOR_TEXTO, True)
        _dibujar_texto(surface, str(self.habilidad), cx, cy + 12, 16, COLOR_TEXTO, True)

        _dibujar_texto(surface, self.nombre, cx, self.rect.y + 94, 17, COLOR_TEXTO, True)
        _dibujar_texto(surface, self.rol, cx, self.rect.y + 118, 12, color_rol, True)

        # Barra de habilidad
        barra_y = self.rect.y + 140
        barra_rect = pygame.Rect(self.rect.x + 14, barra_y, self.ANCHO - 28, 9)
        _rect(surface, (18, 25, 35), barra_rect, 5)
        fill_w = int((self.ANCHO - 28) * self.habilidad / 100)
        fill_rect = pygame.Rect(barra_rect.x, barra_rect.y, fill_w, barra_rect.h)
        _rect(surface, _color_por_nivel(self.habilidad), fill_rect, 5)


# ─────────────────────────────────────────────
# CLASE: ZONA DE EQUIPO
# ─────────────────────────────────────────────
class ZonaEquipo:
    SLOTS = PERSONAS_POR_EQUIPO

    def __init__(self, x: int, y: int, ancho: int, alto: int, etiqueta: str = "Expedición"):
        self.rect = pygame.Rect(x, y, ancho, alto)
        self.etiqueta = etiqueta
        self.tarjetas: list[TarjetaRescatista] = []
        self.activa = False

    def puede_recibir(self) -> bool:
        return len(self.tarjetas) < self.SLOTS

    def recibir_tarjeta(self, tarjeta: TarjetaRescatista) -> None:
        self.tarjetas.append(tarjeta)

    def quitar_tarjeta(self, tarjeta: TarjetaRescatista) -> None:
        if tarjeta in self.tarjetas:
            self.tarjetas.remove(tarjeta)
            self.reordenar()

    def reordenar(self):
        for i, tarjeta in enumerate(self.tarjetas):
            tarjeta.rect.center = self.posicion_por_indice(i)

    def posicion_por_indice(self, idx: int) -> tuple[int, int]:
        cols = 2
        col = idx % cols
        fila = idx // cols

        x = self.rect.x + 45 + col * (TarjetaRescatista.ANCHO + 22) + TarjetaRescatista.ANCHO // 2
        y = self.rect.y + 82 + fila * (TarjetaRescatista.ALTO + 18) + TarjetaRescatista.ALTO // 2
        return (x, y)

    def siguiente_posicion(self) -> tuple[int, int]:
        return self.posicion_por_indice(len(self.tarjetas) - 1)

    def habilidades(self) -> list[int]:
        return [t.habilidad for t in self.tarjetas]

    def desviacion(self) -> int:
        h = self.habilidades()
        if len(h) <= 1:
            return 0
        return max(h) - min(h)

    def dibujar(self, surface: pygame.Surface) -> None:
        color_fondo = (45, 78, 63) if self.activa else COLOR_PANEL
        _sombra(surface, self.rect, 55, 7)
        _rect(surface, color_fondo, self.rect, 22, 2, COLOR_PANEL_BORDE)

        _dibujar_texto(surface, self.etiqueta, self.rect.centerx, self.rect.y + 32, 20, COLOR_ACENTO, True)
        _dibujar_texto(surface, "Arrastra aquí los rescatistas seleccionados", self.rect.centerx, self.rect.y + 58, 14, COLOR_SUBTEXTO)

        for i in range(self.SLOTS):
            if i < len(self.tarjetas):
                continue

            cx, cy = self.posicion_por_indice(i)
            slot_rect = pygame.Rect(0, 0, TarjetaRescatista.ANCHO, TarjetaRescatista.ALTO)
            slot_rect.center = (cx, cy)

            _rect(surface, (30, 42, 60), slot_rect, 16, 2, (63, 82, 106))
            _dibujar_texto(surface, "+", slot_rect.centerx, slot_rect.centery - 10, 38, (80, 100, 125), True)
            _dibujar_texto(surface, "SLOT", slot_rect.centerx, slot_rect.centery + 28, 12, (80, 100, 125), True)

        texto_cnt = f"{len(self.tarjetas)}/{self.SLOTS} rescatistas listos"
        _dibujar_texto(surface, texto_cnt, self.rect.centerx, self.rect.bottom - 24, 14, COLOR_SUBTEXTO, True)


# ─────────────────────────────────────────────
# CLASE: HARMONY METER
# ─────────────────────────────────────────────
class HarmonyMeter:
    def __init__(self, x: int, y: int, ancho: int, alto: int):
        self.rect = pygame.Rect(x, y, ancho, alto)
        self.valor_actual = 0.0
        self.valor_objetivo = 0.0
        self.desviacion = 0
        self.optimo = 0

    def actualizar_desde_zona(self, zona: ZonaEquipo, optimo: int) -> None:
        self.desviacion = zona.desviacion()
        self.optimo = optimo
        self.valor_objetivo = min(self.desviacion / 100, 1.0)

    def actualizar(self) -> None:
        diff = self.valor_objetivo - self.valor_actual
        self.valor_actual += diff * 0.075

    def dibujar(self, surface: pygame.Surface) -> None:
        _sombra(surface, self.rect, 55, 7)
        _rect(surface, COLOR_PANEL, self.rect, 20, 2, COLOR_PANEL_BORDE)

        cx = self.rect.centerx
        _dibujar_texto(surface, "HARMONY METER", cx, self.rect.y + 30, 18, COLOR_ACENTO, True)
        _dibujar_texto(surface, "Equilibrio del equipo", cx, self.rect.y + 54, 13, COLOR_SUBTEXTO)

        centro = (cx, self.rect.y + 145)
        radio = 72

        pygame.draw.circle(surface, (18, 25, 35), centro, radio + 14)
        pygame.draw.circle(surface, (38, 51, 70), centro, radio + 10)

        # Marcas del medidor
        for i in range(0, 101, 10):
            ang = math.radians(210 - i * 2.4)
            x1 = centro[0] + math.cos(ang) * (radio - 3)
            y1 = centro[1] - math.sin(ang) * (radio - 3)
            x2 = centro[0] + math.cos(ang) * (radio + 8)
            y2 = centro[1] - math.sin(ang) * (radio + 8)
            color = COLOR_VERDE if i <= 30 else COLOR_AMARILLO if i <= 60 else COLOR_ROJO
            pygame.draw.line(surface, color, (x1, y1), (x2, y2), 3)

        # Aguja
        angulo = math.radians(210 - self.valor_actual * 240)
        px = centro[0] + math.cos(angulo) * (radio - 12)
        py = centro[1] - math.sin(angulo) * (radio - 12)

        color_aguja = _color_harmony(self.valor_actual)
        pygame.draw.line(surface, color_aguja, centro, (px, py), 6)
        pygame.draw.circle(surface, COLOR_TEXTO, centro, 9)
        pygame.draw.circle(surface, color_aguja, centro, 5)

        if self.valor_actual < 0.30:
            etiqueta, color = "ARMONIOSO ✓", COLOR_VERDE
        elif self.valor_actual < 0.60:
            etiqueta, color = "MODERADO", COLOR_AMARILLO
        else:
            etiqueta, color = "RIESGOSO ✗", COLOR_ROJO

        _dibujar_texto(surface, etiqueta, cx, self.rect.y + 235, 18, color, True)
        _dibujar_texto(surface, f"Desviación: {self.desviacion}", cx, self.rect.y + 265, 14, COLOR_SUBTEXTO)

        if self.optimo > 0:
            _dibujar_texto(surface, f"Óptimo IA: {self.optimo}", cx, self.rect.y + 290, 14, COLOR_VERDE, True)
        else:
            _dibujar_texto(surface, "Presiona Analizar IA", cx, self.rect.y + 290, 13, COLOR_SUBTEXTO)


# ─────────────────────────────────────────────
# PUNTUACIÓN
# ─────────────────────────────────────────────
def calcular_estrellas(desviacion_usuario: int, desviacion_optima: int) -> int:
    if desviacion_optima == 0:
        return 3 if desviacion_usuario == 0 else 1

    ratio = desviacion_usuario / desviacion_optima
    if ratio <= 1.0:
        return 3
    elif ratio <= 1.5:
        return 2
    return 1


def dibujar_resultado(surface: pygame.Surface, estrellas: int, desv_usuario: int, desv_optima: int) -> None:
    overlay = pygame.Surface((ANCHO, ALTO), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 175))
    surface.blit(overlay, (0, 0))

    panel = pygame.Rect(ANCHO // 2 - 280, ALTO // 2 - 205, 560, 410)
    _sombra(surface, panel, 110, 10)
    _rect(surface, COLOR_PANEL, panel, 24, 3, COLOR_ACENTO)

    cx = panel.centerx
    _dibujar_texto(surface, "¡MISIÓN COMPLETADA!", cx, panel.y + 48, 30, COLOR_ACENTO, True)

    for i in range(3):
        color = COLOR_ACENTO if i < estrellas else (70, 80, 95)
        pygame.draw.polygon(surface, color, _puntos_estrella(cx - 80 + i * 80, panel.y + 125, 32))

    _dibujar_texto(surface, f"Tu desviación: {desv_usuario}", cx, panel.y + 205, 19, COLOR_TEXTO, True)
    _dibujar_texto(surface, f"Mejor desviación IA: {desv_optima}", cx, panel.y + 237, 18, COLOR_VERDE, True)

    diferencia = abs(desv_usuario - desv_optima)

    if estrellas == 3:
        mensaje, color_msg = "Excelente. El equipo quedó muy equilibrado.", COLOR_VERDE
    elif estrellas == 2:
        mensaje, color_msg = "Buen trabajo. Se puede mejorar un poco.", COLOR_AMARILLO
    else:
        mensaje, color_msg = "Equipo riesgoso. Revisa mejor la combinación.", COLOR_ROJO

    _dibujar_texto(surface, mensaje, cx, panel.y + 282, 17, color_msg, True)
    _dibujar_texto(surface, f"Diferencia frente a la IA: {diferencia}", cx, panel.y + 313, 15, COLOR_SUBTEXTO)
    _dibujar_texto(surface, "Presiona R para reiniciar", cx, panel.y + 365, 15, COLOR_ACENTO, True)


# ─────────────────────────────────────────────
# JUEGO PRINCIPAL
# ─────────────────────────────────────────────
class JuegoOperacionRescate:
    def __init__(self):
        pygame.init()
        self.pantalla = pygame.display.set_mode((ANCHO, ALTO))
        pygame.display.set_caption("Operación Rescate: Cumbres Salvajes")
        self.reloj = pygame.time.Clock()

        self.estado = "menu"
        self.mision_actual = MISIONES[0]
        self.indice_mision = 0

        self.particulas = [Particula() for _ in range(80)]

        self.btn_play = Boton(ANCHO // 2 - 140, 430, 280, 60, "INICIAR MISIÓN", COLOR_BOTON_NARANJA, COLOR_BOTON_NARANJA_HOV)
        self.btn_salir = Boton(ANCHO // 2 - 140, 505, 280, 52, "SALIR", COLOR_BOTON_GRIS, COLOR_BOTON_GRIS_HOV)
        self.btn_volver = Boton(35, 30, 130, 42, "← VOLVER", COLOR_BOTON_GRIS, COLOR_BOTON_GRIS_HOV)

        self.botones_mision = []
        for i, m in enumerate(MISIONES):
            self.botones_mision.append(
                Boton(
                    190, 145 + i * 102, 900, 76,
                    f"{i + 1}. {m['titulo']}",
                    m["color"],
                    _interpolar(m["color"], COLOR_TEXTO, 0.18)
                )
            )

        self.btn_analizar = Boton(980, 360, 235, 48, "🔍 ANALIZAR IA")
        self.btn_limpiar = Boton(980, 420, 235, 48, "🔄 LIMPIAR", COLOR_BOTON_GRIS, COLOR_BOTON_GRIS_HOV)
        self.btn_enviar = Boton(980, 480, 235, 52, "🚁 ENVIAR EQUIPO", COLOR_BOTON_NARANJA, COLOR_BOTON_NARANJA_HOV)

        self._inicializar()

    def _inicializar(self):
        self.tarjetas: list[TarjetaRescatista] = []
        for i, datos in enumerate(RESCATISTAS_NIVEL_1):
            col = i % 2
            fil = i // 2
            x = 52 + col * 158
            y = 132 + fil * 178
            self.tarjetas.append(TarjetaRescatista(datos, x, y))

        self.zona = ZonaEquipo(
            x=380, y=122,
            ancho=500,
            alto=455,
            etiqueta="ZONA DE EXPEDICIÓN"
        )

        self.meter = HarmonyMeter(x=960, y=85, ancho=275, alto=320)

        self.arrastrada: Optional[TarjetaRescatista] = None
        self.resultado_ia: Optional[dict] = None
        self.desv_optima: int = 0
        self.mostrar_resultado = False

        self.tiempo_total = self.mision_actual["tiempo"]
        self.tiempo_restante = self.tiempo_total
        self.ticks_inicio = pygame.time.get_ticks()

    # ─────────────────────────────────────
    # FONDOS Y PANTALLAS
    # ─────────────────────────────────────
    def dibujar_fondo(self):
        color_mision = self.mision_actual["color"]

        for y in range(ALTO):
            t = y / ALTO
            color = _interpolar(COLOR_FONDO, _interpolar(COLOR_FONDO_2, color_mision, 0.18), t)
            pygame.draw.line(self.pantalla, color, (0, y), (ANCHO, y))

        for p in self.particulas:
            p.actualizar()
            p.dibujar(self.pantalla)

        # Montañas decorativas
        pygame.draw.polygon(self.pantalla, (25, 36, 52), [(0, 650), (220, 360), (470, 650)])
        pygame.draw.polygon(self.pantalla, (32, 46, 66), [(300, 650), (615, 315), (930, 650)])
        pygame.draw.polygon(self.pantalla, (22, 31, 45), [(760, 650), (1030, 365), (1280, 650)])

        pygame.draw.polygon(self.pantalla, (215, 225, 235), [(615, 315), (565, 370), (655, 370)])
        pygame.draw.polygon(self.pantalla, (215, 225, 235), [(1030, 365), (990, 410), (1065, 410)])

    def pantalla_menu(self):
        self.dibujar_fondo()

        pygame.draw.circle(self.pantalla, (42, 58, 80), (ANCHO // 2, 235), 165)
        pygame.draw.circle(self.pantalla, (25, 34, 48), (ANCHO // 2, 235), 138)
        pygame.draw.circle(self.pantalla, COLOR_ACENTO, (ANCHO // 2, 235), 138, 4)

        _dibujar_texto(self.pantalla, "⛰", ANCHO // 2, 142, 52, COLOR_TEXTO, True)
        _dibujar_texto(self.pantalla, "OPERACIÓN", ANCHO // 2, 215, 60, COLOR_ACENTO, True)
        _dibujar_texto(self.pantalla, "RESCATE", ANCHO // 2, 282, 65, COLOR_NARANJA, True)
        _dibujar_texto(self.pantalla, "CUMBRES SALVAJES", ANCHO // 2, 345, 27, COLOR_TEXTO, True)
        _dibujar_texto(self.pantalla, "Videojuego educativo basado en Backtracking con Podas", ANCHO // 2, 385, 18, COLOR_SUBTEXTO)

        self.btn_play.dibujar(self.pantalla)
        self.btn_salir.dibujar(self.pantalla)

        estado = "Algoritmo_1.py conectado ✓" if ALGORITMO_DISPONIBLE else "Algoritmo_1.py no encontrado"
        color_estado = COLOR_VERDE if ALGORITMO_DISPONIBLE else COLOR_ROJO
        _dibujar_texto(self.pantalla, estado, ANCHO // 2, 625, 15, color_estado, True)

    def pantalla_misiones(self):
        self.dibujar_fondo()
        self.btn_volver.dibujar(self.pantalla)

        _dibujar_texto(self.pantalla, "SELECCIÓN DE MISIÓN", ANCHO // 2, 72, 36, COLOR_ACENTO, True)
        _dibujar_texto(self.pantalla, "Cada misión usa el mismo algoritmo, pero cambia el contexto del rescate.", ANCHO // 2, 110, 17, COLOR_SUBTEXTO)

        for boton, mision in zip(self.botones_mision, MISIONES):
            boton.dibujar(self.pantalla)
            _dibujar_texto(self.pantalla, mision["subtitulo"], boton.rect.x + 35, boton.rect.y + 50, 15, COLOR_TEXTO, False, "left")
            _dibujar_texto(self.pantalla, f"Tiempo: {mision['tiempo']}s", boton.rect.right - 35, boton.rect.y + 28, 15, COLOR_TEXTO, True, "right")
            _dibujar_texto(self.pantalla, f"Equipo: {PERSONAS_POR_EQUIPO} miembros", boton.rect.right - 35, boton.rect.y + 53, 14, COLOR_TEXTO, False, "right")

    def dibujar_barra_superior(self):
        _dibujar_texto(self.pantalla, "OPERACIÓN RESCATE", ANCHO // 2, 34, 29, COLOR_ACENTO, True)
        _dibujar_texto(
            self.pantalla,
            f"{self.mision_actual['escenario']} · {self.mision_actual['objetivo']}",
            ANCHO // 2,
            64,
            15,
            COLOR_SUBTEXTO,
        )

        self.btn_volver.dibujar(self.pantalla)

        tiempo_transcurrido = (pygame.time.get_ticks() - self.ticks_inicio) // 1000
        self.tiempo_restante = max(0, self.tiempo_total - tiempo_transcurrido)

        timer_rect = pygame.Rect(1080, 25, 155, 42)
        _rect(self.pantalla, (35, 45, 60), timer_rect, 14, 2, COLOR_PANEL_BORDE)

        color_tiempo = COLOR_VERDE if self.tiempo_restante > 50 else COLOR_AMARILLO if self.tiempo_restante > 20 else COLOR_ROJO
        _dibujar_texto(self.pantalla, f"⏱ {self.tiempo_restante}s", timer_rect.centerx, timer_rect.centery, 18, color_tiempo, True)

    def dibujar_panel_rescatistas(self):
        panel = pygame.Rect(28, 94, 330, 555)
        _sombra(self.pantalla, panel, 55, 7)
        _rect(self.pantalla, COLOR_PANEL, panel, 22, 2, COLOR_PANEL_BORDE)

        _dibujar_texto(self.pantalla, "RESCATISTAS", panel.centerx, panel.y + 30, 21, COLOR_ACENTO, True)
        _dibujar_texto(self.pantalla, "Disponibles para la misión", panel.centerx, panel.y + 55, 14, COLOR_SUBTEXTO)

    def pantalla_juego(self):
        self.dibujar_fondo()
        self.dibujar_barra_superior()
        self.dibujar_panel_rescatistas()

        self.zona.dibujar(self.pantalla)

        self.meter.actualizar_desde_zona(self.zona, self.desv_optima)
        self.meter.actualizar()
        self.meter.dibujar(self.pantalla)

        self.btn_analizar.dibujar(self.pantalla)
        self.btn_limpiar.dibujar(self.pantalla)
        self.btn_enviar.dibujar(self.pantalla)

        ayuda = pygame.Rect(380, 600, 500, 48)
        _rect(self.pantalla, (30, 40, 55), ayuda, 16, 1, COLOR_PANEL_BORDE)
        _dibujar_texto(self.pantalla, f"Arrastra {TAMANO_EQUIPO} rescatistas · Analiza con IA · Envía el equipo", ayuda.centerx, ayuda.y + 18, 15, COLOR_SUBTEXTO)
        _dibujar_texto(self.pantalla, "R = reiniciar    ESC = salir", ayuda.centerx, ayuda.y + 36, 13, COLOR_SUBTEXTO)

        # Dibujar tarjetas
        for t in self.zona.tarjetas:
            if not t.arrastrando:
                t.dibujar(self.pantalla)

        for t in self.tarjetas:
            if t.en_zona is None and not t.arrastrando:
                t.dibujar(self.pantalla)

        if self.arrastrada:
            self.arrastrada.dibujar(self.pantalla)

        if self.mostrar_resultado:
            desv_usuario = self.zona.desviacion()
            dibujar_resultado(
                self.pantalla,
                calcular_estrellas(desv_usuario, self.desv_optima),
                desv_usuario,
                self.desv_optima,
            )

    # ─────────────────────────────────────
    # EVENTOS Y LÓGICA
    # ─────────────────────────────────────
    def manejar_eventos(self):
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if evento.type == pygame.KEYDOWN:
                if evento.key == pygame.K_ESCAPE:
                    pygame.quit()
                    sys.exit()
                if evento.key == pygame.K_r and self.estado == "juego":
                    self._inicializar()

            if self.estado == "menu":
                if self.btn_play.manejar_evento(evento):
                    self.estado = "misiones"
                if self.btn_salir.manejar_evento(evento):
                    pygame.quit()
                    sys.exit()

            elif self.estado == "misiones":
                if self.btn_volver.manejar_evento(evento):
                    self.estado = "menu"

                for i, boton in enumerate(self.botones_mision):
                    if boton.manejar_evento(evento):
                        self.indice_mision = i
                        self.mision_actual = MISIONES[i]
                        self._inicializar()
                        self.estado = "juego"

            elif self.estado == "juego":
                if self.btn_volver.manejar_evento(evento):
                    self.estado = "misiones"

                if self.btn_analizar.manejar_evento(evento):
                    self._ejecutar_ia()

                if self.btn_limpiar.manejar_evento(evento):
                    self._limpiar_zona()

                if self.btn_enviar.manejar_evento(evento):
                    if len(self.zona.tarjetas) == TAMANO_EQUIPO:
                        if self.resultado_ia is None:
                            self._ejecutar_ia()
                        self.mostrar_resultado = True
                    else:
                        print(f"⚠ Debes colocar {TAMANO_EQUIPO} rescatistas antes de enviar.")

                if evento.type == pygame.MOUSEBUTTONDOWN and evento.button == 1:
                    if not self.mostrar_resultado:
                        mx, my = evento.pos

                        for t in reversed(self.zona.tarjetas):
                            if t.rect.collidepoint(mx, my):
                                t.iniciar_arrastre(mx, my)
                                self.arrastrada = t
                                break
                        else:
                            for t in reversed(self.tarjetas):
                                if t.rect.collidepoint(mx, my) and t.en_zona is None:
                                    t.iniciar_arrastre(mx, my)
                                    self.arrastrada = t
                                    break

                if evento.type == pygame.MOUSEMOTION:
                    if self.arrastrada:
                        self.arrastrada.mover(*evento.pos)
                        self.zona.activa = self.zona.rect.collidepoint(evento.pos)

                    for t in self.tarjetas:
                        t.hover = t.rect.collidepoint(evento.pos) and not t.arrastrando

                if evento.type == pygame.MOUSEBUTTONUP and evento.button == 1:
                    if self.arrastrada:
                        self.arrastrada.soltar([self.zona])
                        self.arrastrada = None
                        self.zona.activa = False

    def _ejecutar_ia(self):
        if not ALGORITMO_DISPONIBLE:
            print("⚠️ Algoritmo_1.py no disponible.")
            return

        personas = [{"nombre": t.nombre, "habilidad": t.habilidad} for t in self.tarjetas]

        try:
            resultado = resolver_distribucion(
                personas,
                cantidad_equipos=CANTIDAD_EQUIPOS,
                guardar_historial=False
            )

            self.desv_optima = resultado["mejor_desviacion"]
            self.resultado_ia = resultado

            print("\n✅ Distribución óptima encontrada:")
            for i, equipo in enumerate(resultado["mejores_equipos"]):
                nombres = [p["nombre"] for p in equipo]
                habs = [p["habilidad"] for p in equipo]
                desv = max(habs) - min(habs) if len(habs) > 1 else 0
                print(f"   Equipo {i + 1}: {nombres} — habilidades: {habs} — desviación: {desv}")

            print(f"   Desviación total óptima: {self.desv_optima}")
            print(f"   Estadísticas: {resultado['estadisticas']}\n")

        except Exception as e:
            print(f"❌ Error en algoritmo: {e}")

    def _limpiar_zona(self):
        for t in list(self.zona.tarjetas):
            self.zona.quitar_tarjeta(t)
            t.en_zona = None
            t._iniciar_retorno()

        self.mostrar_resultado = False

    def actualizar(self):
        for t in self.tarjetas:
            t.actualizar()

    def dibujar(self):
        if self.estado == "menu":
            self.pantalla_menu()
        elif self.estado == "misiones":
            self.pantalla_misiones()
        elif self.estado == "juego":
            self.pantalla_juego()

        pygame.display.flip()

    def ejecutar(self):
        while True:
            self.manejar_eventos()
            self.actualizar()
            self.dibujar()
            self.reloj.tick(FPS)


# ─────────────────────────────────────────────
# PUNTO DE ENTRADA
# ─────────────────────────────────────────────
if __name__ == "__main__":
    juego = JuegoOperacionRescate()
    juego.ejecutar()
